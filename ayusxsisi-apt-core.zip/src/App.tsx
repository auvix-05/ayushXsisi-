import React, { useState, useEffect } from 'react';
import { WebsiteNav } from './components/WebsiteNav.tsx';
import { HeroSection } from './components/HeroSection.tsx';
import { CapabilitiesSection } from './components/CapabilitiesSection.tsx';
import { InteractiveShowcaseSection } from './components/InteractiveShowcaseSection.tsx';
import { ArchitectureSpecsSection } from './components/ArchitectureSpecsSection.tsx';
import { SubmitRepoSection } from './components/SubmitRepoSection.tsx';
import { WebsiteFooter } from './components/WebsiteFooter.tsx';
import { AddRepoModal } from './components/AddRepoModal.tsx';
import { StatusTerminal } from './components/StatusTerminal.tsx';
import { api } from './lib/api.ts';
import type { Repo } from './lib/types.ts';

export default function App() {
  const [repos, setRepos] = useState<Repo[]>([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const fetchRepos = async () => {
    try {
      const data = await api.getRepos();
      setRepos(data);
    } catch (err) {
      console.error('Failed to load repositories:', err);
    }
  };

  useEffect(() => {
    fetchRepos();
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans selection:bg-sky-500/30 selection:text-sky-200 relative">
      {/* Website Top Bar */}
      <WebsiteNav onOpenSubmit={() => scrollToSection('submit-repo')} />

      {/* Main Website Sections */}
      <main className="flex-1">
        {/* 1. Hero Section */}
        <HeroSection
          onExploreDemo={() => scrollToSection('interactive-showcase')}
          onViewSpecs={() => scrollToSection('architecture-specs')}
        />

        {/* 2. Core Capabilities */}
        <CapabilitiesSection />

        {/* 3. Interactive Sandbox / Live Product Experience */}
        <InteractiveShowcaseSection
          repos={repos}
          onRefreshRepos={fetchRepos}
          onOpenAddModal={() => setIsAddModalOpen(true)}
        />

        {/* 4. Architecture & Technical Specifications */}
        <ArchitectureSpecsSection />

        {/* 5. Repository Submission / Lead Capture */}
        <SubmitRepoSection onRepoAdded={fetchRepos} />
      </main>

      {/* Website Footer */}
      <WebsiteFooter />

      {/* Add Repository Quick Modal */}
      <AddRepoModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAdded={fetchRepos}
      />

      {/* Small right-side APT status terminal */}
      <StatusTerminal repos={repos} onRefreshRepos={fetchRepos} />
    </div>
  );
}
