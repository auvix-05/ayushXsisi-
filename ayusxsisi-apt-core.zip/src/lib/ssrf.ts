/**
 * SSRF (Server-Side Request Forgery) Prevention Engine
 * Validates outgoing repository URLs against private, link-local, loopback,
 * and cloud instance metadata addresses according to IANA and RFC standards.
 */

import type { SSRFResult } from './types.ts';

// Check if string is a numeric IPv4
function isIPv4(host: string): boolean {
  const parts = host.split('.');
  if (parts.length !== 4) return false;
  return parts.every(p => {
    const n = Number(p);
    return !isNaN(n) && n >= 0 && n <= 255 && String(n) === p;
  });
}

function isPrivateIPv4(ip: string): { private: boolean; reason?: string } {
  const parts = ip.split('.').map(Number);
  const [a, b] = parts;

  // 127.0.0.0/8 (Loopback)
  if (a === 127) {
    return { private: true, reason: 'RFC 1122: Loopback IP address (127.0.0.0/8)' };
  }

  // 0.0.0.0/8 (Current network)
  if (a === 0) {
    return { private: true, reason: 'RFC 1122: Current network "this host" (0.0.0.0/8)' };
  }

  // 10.0.0.0/8 (Private A)
  if (a === 10) {
    return { private: true, reason: 'RFC 1918: Private Network Class A (10.0.0.0/8)' };
  }

  // 172.16.0.0/12 (Private B)
  if (a === 172 && b >= 16 && b <= 31) {
    return { private: true, reason: 'RFC 1918: Private Network Class B (172.16.0.0/12)' };
  }

  // 192.168.0.0/16 (Private C)
  if (a === 192 && b === 168) {
    return { private: true, reason: 'RFC 1918: Private Network Class C (192.168.0.0/16)' };
  }

  // 169.254.0.0/16 (Link Local & Cloud Metadata)
  if (a === 169 && b === 254) {
    return { private: true, reason: 'RFC 3927: Link-Local & Cloud Metadata Service (169.254.0.0/16)' };
  }

  // 100.64.0.0/10 (Carrier-Grade NAT)
  if (a === 100 && b >= 64 && b <= 127) {
    return { private: true, reason: 'RFC 6598: Shared Address Space / CGNAT (100.64.0.0/10)' };
  }

  // 224.0.0.0/4 (Multicast)
  if (a >= 224 && a <= 239) {
    return { private: true, reason: 'RFC 5771: Multicast Address Space' };
  }

  // 240.0.0.0/4 (Reserved)
  if (a >= 240) {
    return { private: true, reason: 'RFC 1112: Reserved / Broadcast Address Space' };
  }

  return { private: false };
}

function isPrivateIPv6(host: string): { private: boolean; reason?: string } {
  const clean = host.replace(/[\[\]]/g, '').toLowerCase();

  if (clean === '::1' || clean === '0000:0000:0000:0000:0000:0000:0000:0001') {
    return { private: true, reason: 'RFC 4291: IPv6 Loopback (::1)' };
  }
  if (clean === '::' || clean === '0000:0000:0000:0000:0000:0000:0000:0000') {
    return { private: true, reason: 'RFC 4291: IPv6 Unspecified address' };
  }
  if (clean.startsWith('fe80:') || clean.startsWith('fe8') || clean.startsWith('fe9') || clean.startsWith('fea') || clean.startsWith('feb')) {
    return { private: true, reason: 'RFC 4291: IPv6 Link-Local Unicast' };
  }
  if (clean.startsWith('fc') || clean.startsWith('fd')) {
    return { private: true, reason: 'RFC 4193: IPv6 Unique Local Address (ULA)' };
  }
  if (clean.startsWith('ff')) {
    return { private: true, reason: 'RFC 4291: IPv6 Multicast' };
  }

  return { private: false };
}

/**
 * Validates a target URL before outbound network requests.
 * Checks protocol, hostname, domain blocks, and resolved IP addresses.
 */
export async function validateSafeUrl(rawUrl: string): Promise<SSRFResult> {
  if (!rawUrl || typeof rawUrl !== 'string') {
    return { safe: false, reason: 'Invalid or empty URL parameter provided' };
  }

  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    return { safe: false, reason: 'Malformed URL: unable to parse standard RFC 3986 URL' };
  }

  // Only permit HTTP and HTTPS
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return {
      safe: false,
      protocol: parsed.protocol,
      reason: `Disallowed protocol "${parsed.protocol}". Only standard http: and https: protocols are permitted.`
    };
  }

  const hostname = parsed.hostname.toLowerCase();

  // Known dangerous hostnames & cloud metadata services
  const blockedHostnames = new Set([
    'localhost',
    'localhost.localdomain',
    'ip6-localhost',
    'ip6-loopback',
    'metadata.google.internal',
    'metadata',
    'instance-data',
    '169.254.169.254'
  ]);

  if (blockedHostnames.has(hostname) || hostname.endsWith('.localhost') || hostname.endsWith('.internal')) {
    return {
      safe: false,
      hostname,
      reason: `Blocked target host "${hostname}" (Loopback or Internal Cloud Metadata endpoint).`
    };
  }

  // Check if raw hostname is already an IPv4 literal
  if (isIPv4(hostname)) {
    const ipv4Check = isPrivateIPv4(hostname);
    if (ipv4Check.private) {
      return {
        safe: false,
        hostname,
        ip: hostname,
        reason: ipv4Check.reason
      };
    }
    return { safe: true, hostname, ip: hostname, protocol: parsed.protocol };
  }

  // Check if raw hostname is an IPv6 literal
  if (hostname.startsWith('[') || hostname.includes(':')) {
    const ipv6Check = isPrivateIPv6(hostname);
    if (ipv6Check.private) {
      return {
        safe: false,
        hostname,
        ip: hostname,
        reason: ipv6Check.reason
      };
    }
  }

  // If in Node server environment (not browser), perform DNS lookup to block DNS rebinding to private IPs
  if (typeof window === 'undefined' && typeof process !== 'undefined' && process.versions?.node) {
    try {
      const mod = 'dns';
      const dns = await import(/* @vite-ignore */ mod);
      const lookup = await dns.promises.lookup(hostname, { all: true });

      for (const entry of lookup) {
        if (entry.family === 4) {
          const check = isPrivateIPv4(entry.address);
          if (check.private) {
            return {
              safe: false,
              hostname,
              ip: entry.address,
              reason: `DNS Rebinding Defense: Hostname "${hostname}" resolves to protected IP ${entry.address} (${check.reason}).`
            };
          }
        } else if (entry.family === 6) {
          const check = isPrivateIPv6(entry.address);
          if (check.private) {
            return {
              safe: false,
              hostname,
              ip: entry.address,
              reason: `DNS Rebinding Defense: Hostname "${hostname}" resolves to protected IPv6 ${entry.address} (${check.reason}).`
            };
          }
        }
      }

      return {
        safe: true,
        hostname,
        ip: lookup[0]?.address || 'DNS Verified',
        protocol: parsed.protocol
      };
    } catch (dnsErr: any) {
      return {
        safe: false,
        hostname,
        reason: `DNS Resolution failure for "${hostname}": ${dnsErr.message || 'Host not found'}`
      };
    }
  }

  return { safe: true, hostname, protocol: parsed.protocol };
}
