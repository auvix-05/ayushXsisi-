/**
 * Debian RFC822 Control Format Parser & Field Normalizer
 * Conforms to Debian Policy Manual standards for multiline folding.
 */

import type { DebianControlMap } from './types.ts';

/**
 * Parses Debian RFC822 control format text into array of structured key-value maps.
 * Handles folded/multiline fields according to Debian Policy Manual standards.
 * @param rawText string
 * @returns Array<DebianControlMap>
 */
export function parseDebianControl(rawText: string): Array<DebianControlMap> {
  const blocks = rawText.split(/\r?\n\r?\n/);
  const packages: Array<DebianControlMap> = [];

  for (const block of blocks) {
    if (!block.trim()) continue;

    const lines = block.split(/\r?\n/);
    const pkgData: DebianControlMap = {};
    let currentKey: string | null = null;

    for (const line of lines) {
      if (line.startsWith(' ') || line.startsWith('\t')) {
        // Multiline field continuation (e.g. detailed Description)
        if (currentKey) {
          pkgData[currentKey] += '\n' + line.trim();
        }
      } else {
        const colonIndex = line.indexOf(':');
        if (colonIndex !== -1) {
          currentKey = line.substring(0, colonIndex).trim().toLowerCase();
          const value = line.substring(colonIndex + 1).trim();
          pkgData[currentKey] = value;
        }
      }
    }

    if (pkgData['package'] && pkgData['version']) {
      packages.push(pkgData);
    }
  }

  return packages;
}

/**
 * Normalizes categories into predefined high-fidelity categories.
 */
export function mapSectionToCategory(section = ''): string {
  const s = section.toLowerCase();
  if (s.includes('theme') || s.includes('wallpaper') || s.includes('sound')) return 'Customization and Themes';
  if (s.includes('lockscreen') || s.includes('lock screen')) return 'Lock Screen';
  if (s.includes('controlcenter') || s.includes('control center')) return 'Control Center';
  if (s.includes('statusbar') || s.includes('status bar')) return 'Status Bar';
  if (s.includes('file') || s.includes('archive')) return 'File Management';
  if (s.includes('security') || s.includes('privacy') || s.includes('networking')) return 'Security and Privacy';
  if (s.includes('productivity') || s.includes('office')) return 'Productivity';
  if (s.includes('developer') || s.includes('development') || s.includes('terminal')) return 'Development Tools';
  if (s.includes('legacy') || s.includes('archived')) return 'Legacy Packages';
  return 'System Utilities';
}

/**
 * Lints Debian RFC822 Control text and reports syntax issues, missing mandatory fields, etc.
 */
export function lintDebianControl(rawText: string) {
  const errors: string[] = [];
  const warnings: string[] = [];

  const packages = parseDebianControl(rawText);

  if (packages.length === 0) {
    errors.push('No valid package paragraph identified. Make sure "Package:" and "Version:" fields exist and paragraphs are separated by blank lines.');
    return { valid: false, errors, warnings, count: 0, packages };
  }

  const standardFields = ['package', 'version', 'architecture', 'maintainer', 'description', 'section'];

  packages.forEach((pkg, index) => {
    const pkgName = pkg['package'] || `Package #${index + 1}`;
    
    // Check package name format (lowercase alphanumeric, plus, minus, dot)
    if (!/^[a-z0-9][a-z0-9+.-]+$/i.test(pkg['package'])) {
      warnings.push(`[${pkgName}] Package identifier "${pkg['package']}" should typically adhere to standard Debian naming conventions (alphanumeric, plus, hyphen, period).`);
    }

    // Check mandatory fields
    if (!pkg['architecture']) {
      warnings.push(`[${pkgName}] Architecture field is omitted; defaults to 'iphoneos-arm' or 'all'.`);
    }
    if (!pkg['maintainer'] && !pkg['author']) {
      warnings.push(`[${pkgName}] Maintainer or Author field recommended for APT indexing.`);
    }
    if (!pkg['description']) {
      warnings.push(`[${pkgName}] Description field missing.`);
    }

    // Check size format if present
    if (pkg['size'] && isNaN(parseInt(pkg['size'], 10))) {
      errors.push(`[${pkgName}] Size field "${pkg['size']}" must be an integer byte count.`);
    }
  });

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    count: packages.length,
    packages
  };
}
