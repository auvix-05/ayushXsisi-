/**
 * SQLite-compatible High-Performance In-Memory & Persisted Database Engine
 * Implements the exact .prepare(sql).get() / .all() / .run() and .transaction() APIs
 * required by the ayusXsisi APT Core.
 */

import type { Repo, PackageItem, PackageVersion, ImportLog } from './types.ts';

// In-memory data structures
class DatabaseEngine {
  private repos: Map<number, Repo> = new Map();
  private packages: Map<string, PackageItem> = new Map();
  private packageVersions: Map<string, PackageVersion> = new Map(); // key: `${pkg_id}@${version}`
  private importLogs: ImportLog[] = [];
  private nextRepoId = 1;
  private nextLogId = 1;

  constructor() {
    this.seedInitialData();
  }

  private seedInitialData() {
    // 1. Initial Repositories
    const defaultRepos: Array<Omit<Repo, 'id' | 'package_count'>> = [
      {
        name: 'Chariz Official',
        url: 'https://repo.chariz.com/',
        icon_url: 'https://repo.chariz.com/CydiaIcon.png',
        sync_status: 'success',
        error_message: null,
        last_sync: new Date(Date.now() - 3600000).toISOString(),
        created_at: new Date(Date.now() - 86400000 * 5).toISOString(),
        updated_at: new Date(Date.now() - 3600000).toISOString(),
      },
      {
        name: 'Havoc Community Repo',
        url: 'https://havoc.app/',
        icon_url: 'https://havoc.app/icons/icon.png',
        sync_status: 'success',
        error_message: null,
        last_sync: new Date(Date.now() - 7200000).toISOString(),
        created_at: new Date(Date.now() - 86400000 * 4).toISOString(),
        updated_at: new Date(Date.now() - 7200000).toISOString(),
      },
      {
        name: 'Procursus APT Bootstrap',
        url: 'https://apt.procurs.us/',
        icon_url: 'https://apt.procurs.us/CydiaIcon.png',
        sync_status: 'success',
        error_message: null,
        last_sync: new Date(Date.now() - 14400000).toISOString(),
        created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
        updated_at: new Date(Date.now() - 14400000).toISOString(),
      },
      {
        name: 'opa334 Repository',
        url: 'https://opa334.github.io/',
        icon_url: 'https://opa334.github.io/CydiaIcon.png',
        sync_status: 'success',
        error_message: null,
        last_sync: new Date(Date.now() - 1800000).toISOString(),
        created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
        updated_at: new Date(Date.now() - 1800000).toISOString(),
      }
    ];

    defaultRepos.forEach(r => {
      const id = this.nextRepoId++;
      this.repos.set(id, { ...r, id, package_count: 0 });
    });

    // 2. Initial Packages
    const samplePackages: Array<PackageItem & { versionsList?: PackageVersion[] }> = [
      {
        package_id: 'com.opa334.choicy',
        name: 'Choicy',
        section: 'System Utilities',
        latest_version: '1.4.11',
        description: 'Advanced, granular tweak configurator for Substrate, Substitute, and ElleKit. Selectively disable or enable dylib injection on a per-app or per-daemon basis.',
        maintainer: 'opa334 <opa334@github.com>',
        author: 'opa334',
        architecture: 'iphoneos-arm64',
        icon_url: 'https://opa334.github.io/icons/com.opa334.choicy.png',
        download_url: 'https://opa334.github.io/debs/com.opa334.choicy_1.4.11_iphoneos-arm64.deb',
        min_ios: '10.0',
        max_ios: '27.0',
        compatibility_status: 'Verified',
        is_legacy: 0,
        repo_id: 4,
        updated_at: new Date().toISOString(),
        versionsList: [
          {
            package_id: 'com.opa334.choicy',
            version: '1.4.11',
            download_url: 'https://opa334.github.io/debs/com.opa334.choicy_1.4.11_iphoneos-arm64.deb',
            size_bytes: 428912,
            md5sum: 'f9d3b7643b17c2f82110c732b13f19e4',
            sha256: '9b282db14f3b2361ac87955c478a5940f89bbd0a7f14b9c1d2e5a31b49f12345',
            dependencies: 'mobilesubstrate (>= 0.9.5000), preferenceloader',
            conflicts: null,
            architecture: 'iphoneos-arm64',
            repo_id: 4
          },
          {
            package_id: 'com.opa334.choicy',
            version: '1.4.10',
            download_url: 'https://opa334.github.io/debs/com.opa334.choicy_1.4.10_iphoneos-arm64.deb',
            size_bytes: 421040,
            md5sum: '8b94101e5c27f91c94022a101bcf3291',
            sha256: '4c7d91e3f892a0b127419e048759123847a98bcdef10293847561a0293847561',
            dependencies: 'mobilesubstrate (>= 0.9.5000)',
            conflicts: null,
            architecture: 'iphoneos-arm64',
            repo_id: 4
          }
        ]
      },
      {
        package_id: 'com.opa334.trollstore',
        name: 'TrollStore',
        section: 'System Utilities',
        latest_version: '2.0.15',
        description: 'Jailed iOS app that can permanently install IPAs with arbitrary entitlements and root helper permissions leveraging CoreTrust CVE-2022-26766 and CVE-2023-41991.',
        maintainer: 'opa334 <opa334@github.com>',
        author: 'opa334',
        architecture: 'iphoneos-arm64',
        icon_url: 'https://opa334.github.io/icons/com.opa334.trollstore.png',
        download_url: 'https://github.com/opa334/TrollStore/releases/download/2.0.15/TrollStore.tar',
        min_ios: '10.0',
        max_ios: '27.0',
        compatibility_status: 'Verified',
        is_legacy: 0,
        repo_id: 4,
        updated_at: new Date().toISOString(),
        versionsList: [
          {
            package_id: 'com.opa334.trollstore',
            version: '2.0.15',
            download_url: 'https://github.com/opa334/TrollStore/releases/download/2.0.15/TrollStore.tar',
            size_bytes: 3145728,
            md5sum: 'a1b2c3d4e5f60718293a4b5c6d7e8f90',
            sha256: '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef',
            dependencies: 'firmware (>= 10.0), firmware (<= 27.0)',
            conflicts: null,
            architecture: 'iphoneos-arm64',
            repo_id: 4
          }
        ]
      },
      {
        package_id: 'ws.hbang.common',
        name: 'Cephei Defaults',
        section: 'Development Tools',
        latest_version: '2.0.2',
        description: 'A modern, resilient framework for developers to create preferences and support functionality for jailbreak tweaks and tweaks extensions.',
        maintainer: 'HASHBANG Productions <support@hbang.ws>',
        author: 'HASHBANG Productions',
        architecture: 'iphoneos-arm64',
        icon_url: 'https://repo.chariz.com/icons/ws.hbang.common.png',
        download_url: 'https://repo.chariz.com/debs/ws.hbang.common_2.0.2.deb',
        min_ios: '10.0',
        max_ios: '27.0',
        compatibility_status: 'Reported',
        is_legacy: 0,
        repo_id: 1,
        updated_at: new Date().toISOString(),
        versionsList: [
          {
            package_id: 'ws.hbang.common',
            version: '2.0.2',
            download_url: 'https://repo.chariz.com/debs/ws.hbang.common_2.0.2.deb',
            size_bytes: 184320,
            md5sum: '49fe21a37812903bb1cfca44b8b603ef',
            sha256: 'e823a7bb84c1f92e92314a919018c1d5301824345719efcb8471928471920384',
            dependencies: 'firmware (>= 10.0), mobilesubstrate',
            conflicts: null,
            architecture: 'iphoneos-arm64',
            repo_id: 1
          }
        ]
      },
      {
        package_id: 'com.spark.snowboard',
        name: 'SnowBoard',
        section: 'Customization and Themes',
        latest_version: '1.5.28-Beta1',
        description: 'SnowBoard is a lightweight, full-featured theming engine for iOS. It is designed to be fully modular and run seamlessly without battery drain.',
        maintainer: 'SparkDev <spark@sparkdev.me>',
        author: 'SparkDev & Dennis D. Bednarz',
        architecture: 'iphoneos-arm64',
        icon_url: 'https://havoc.app/icons/com.spark.snowboard.png',
        download_url: 'https://havoc.app/debs/com.spark.snowboard_1.5.28.deb',
        min_ios: '10.0',
        max_ios: '27.0',
        compatibility_status: 'Verified',
        is_legacy: 0,
        repo_id: 2,
        updated_at: new Date().toISOString(),
        versionsList: [
          {
            package_id: 'com.spark.snowboard',
            version: '1.5.28-Beta1',
            download_url: 'https://havoc.app/debs/com.spark.snowboard_1.5.28.deb',
            size_bytes: 849312,
            md5sum: 'd3b07384d113edec49eaa6238ad5ff00',
            sha256: 'f45b678901234567890abcdef1234567890abcdef1234567890abcdef1234567',
            dependencies: 'mobilesubstrate, preferenceloader',
            conflicts: 'winterboard, anemone',
            architecture: 'iphoneos-arm64',
            repo_id: 2
          }
        ]
      },
      {
        package_id: 'openssh',
        name: 'OpenSSH Server & Client',
        section: 'Security and Privacy',
        latest_version: '9.6p1-1',
        description: 'OpenSSH is the premier connectivity tool for remote login with the SSH protocol. It encrypts all traffic to eliminate eavesdropping and connection hijacking.',
        maintainer: 'Procursus Team <maintainers@procurs.us>',
        author: 'OpenSSH Project',
        architecture: 'iphoneos-arm64',
        icon_url: null,
        download_url: 'https://apt.procurs.us/pool/main/o/openssh/openssh_9.6p1-1_iphoneos-arm64.deb',
        min_ios: '10.0',
        max_ios: '27.0',
        compatibility_status: 'Verified',
        is_legacy: 0,
        repo_id: 3,
        updated_at: new Date().toISOString(),
        versionsList: [
          {
            package_id: 'openssh',
            version: '9.6p1-1',
            download_url: 'https://apt.procurs.us/pool/main/o/openssh/openssh_9.6p1-1_iphoneos-arm64.deb',
            size_bytes: 1420800,
            md5sum: '5eb63bbbe01eeed093cb22bb8f5acdc3',
            sha256: 'a9b8c7d6e5f41234567890abcdef1234567890abcdef1234567890abcdef1234',
            dependencies: 'libssl3, libcrypt2, libedit0',
            conflicts: null,
            architecture: 'iphoneos-arm64',
            repo_id: 3
          }
        ]
      },
      {
        package_id: 'com.charliewhile.velvet2',
        name: 'Velvet 2',
        section: 'Customization and Themes',
        latest_version: '2.1.0',
        description: 'Revolutionize your iOS notifications. Customize banners, lockscreen alerts, notification center, and notification indicators with dynamic app color matching.',
        maintainer: 'Charlie While <charlie@while.dev>',
        author: 'Charlie While',
        architecture: 'iphoneos-arm64',
        icon_url: 'https://repo.chariz.com/icons/com.charliewhile.velvet2.png',
        download_url: 'https://repo.chariz.com/debs/com.charliewhile.velvet2_2.1.0.deb',
        min_ios: '10.0',
        max_ios: '27.0',
        compatibility_status: 'Verified',
        is_legacy: 0,
        repo_id: 1,
        updated_at: new Date().toISOString(),
        versionsList: [
          {
            package_id: 'com.charliewhile.velvet2',
            version: '2.1.0',
            download_url: 'https://repo.chariz.com/debs/com.charliewhile.velvet2_2.1.0.deb',
            size_bytes: 614400,
            md5sum: 'a7c98124ef12048f081239c019284fae',
            sha256: '9182374619283746192837461928374619283746192837461928374619283746',
            dependencies: 'mobilesubstrate, preferenceloader, ws.hbang.alderis',
            conflicts: null,
            architecture: 'iphoneos-arm64',
            repo_id: 1
          }
        ]
      },
      {
        package_id: 'org.cydia.legacy.winterboard',
        name: 'WinterBoard (Legacy)',
        section: 'Legacy Packages',
        latest_version: '0.9.3919',
        description: 'The grandfather theme manager for early iOS versions (iOS 2.0 to iOS 9.3.3). Kept for historical archiving and vintage 32-bit idevices.',
        maintainer: 'Jay Freeman (saurik) <saurik@saurik.com>',
        author: 'saurik',
        architecture: 'iphoneos-arm',
        icon_url: null,
        download_url: 'http://apt.saurik.com/debs/winterboard_0.9.3919_iphoneos-arm.deb',
        min_ios: '10.0',
        max_ios: '27.0',
        compatibility_status: 'Legacy (Phoenix / Cydia)',
        is_legacy: 1,
        repo_id: 1,
        updated_at: new Date(Date.now() - 86400000 * 300).toISOString(),
        versionsList: [
          {
            package_id: 'org.cydia.legacy.winterboard',
            version: '0.9.3919',
            download_url: 'http://apt.saurik.com/debs/winterboard_0.9.3919_iphoneos-arm.deb',
            size_bytes: 384000,
            md5sum: 'e4d909c290d0fb1ca068ffaddf22cbd0',
            sha256: 'c019284719283746192837461928374619283746192837461928374619283746',
            dependencies: 'firmware (<= 9.3.5), mobilesubstrate',
            conflicts: 'anemone',
            architecture: 'iphoneos-arm',
            repo_id: 1
          }
        ]
      }
    ];

    samplePackages.forEach(pkg => {
      const { versionsList, ...item } = pkg;
      this.packages.set(item.package_id, item);

      if (versionsList) {
        versionsList.forEach(ver => {
          this.packageVersions.set(`${ver.package_id}@${ver.version}`, ver);
        });
      }
    });

    // Initial log
    this.importLogs.push({
      id: this.nextLogId++,
      repo_id: 1,
      repo_name: 'Chariz Official',
      status: 'success',
      packages_imported: 2,
      error_message: null,
      created_at: new Date(Date.now() - 3600000).toISOString()
    });

    this.updateRepoCounts();
  }

  private updateRepoCounts() {
    this.repos.forEach(repo => {
      let count = 0;
      this.packages.forEach(pkg => {
        if (pkg.repo_id === repo.id) count++;
      });
      repo.package_count = count;
    });
  }

  /**
   * Statement emulation for SQLite API
   */
  public prepare<T = any>(sql: string) {
    const trimmed = sql.trim();
    const self = this;

    return {
      get(...params: any[]): T | null {
        if (trimmed.toUpperCase().includes('FROM REPOS WHERE ID = ?')) {
          const id = Number(params[0]);
          return (self.repos.get(id) || null) as unknown as T;
        }

        if (trimmed.toUpperCase().includes('FROM PACKAGES WHERE PACKAGE_ID = ?')) {
          const pkgId = String(params[0]);
          const pkg = self.packages.get(pkgId);
          if (!pkg) return null;
          const versions = Array.from(self.packageVersions.values()).filter(v => v.package_id === pkgId);
          return { ...pkg, versions } as unknown as T;
        }

        return null;
      },

      all(...params: any[]): T[] {
        self.updateRepoCounts();

        if (trimmed.toUpperCase().includes('FROM REPOS')) {
          return Array.from(self.repos.values()) as unknown as T[];
        }

        if (trimmed.toUpperCase().includes('FROM PACKAGES')) {
          const list = Array.from(self.packages.values()).map(pkg => {
            const repo = self.repos.get(pkg.repo_id);
            return {
              ...pkg,
              repo_name: repo ? repo.name : `Repo #${pkg.repo_id}`
            };
          });
          return list as unknown as T[];
        }

        if (trimmed.toUpperCase().includes('FROM IMPORT_LOGS')) {
          const logs = self.importLogs.map(log => {
            const repo = self.repos.get(log.repo_id);
            return {
              ...log,
              repo_name: repo ? repo.name : `Repo #${log.repo_id}`
            };
          });
          return logs as unknown as T[];
        }

        return [];
      },

      run(...params: any[]) {
        const upper = trimmed.toUpperCase();

        // 1. UPDATE repos SET sync_status = 'syncing'...
        if (upper.startsWith('UPDATE REPOS SET SYNC_STATUS = \'SYNCING\'')) {
          const repoId = Number(params[0]);
          const repo = self.repos.get(repoId);
          if (repo) {
            repo.sync_status = 'syncing';
            repo.error_message = null;
            repo.updated_at = new Date().toISOString();
          }
          return { changes: 1 };
        }

        // 2. UPDATE repos SET last_sync = CURRENT_TIMESTAMP, sync_status = 'success'
        if (upper.includes("SYNC_STATUS = 'SUCCESS'")) {
          const repoId = Number(params[0]);
          const repo = self.repos.get(repoId);
          if (repo) {
            repo.sync_status = 'success';
            repo.last_sync = new Date().toISOString();
            repo.error_message = null;
            repo.updated_at = new Date().toISOString();
          }
          self.updateRepoCounts();
          return { changes: 1 };
        }

        // 3. UPDATE repos SET sync_status = 'error', error_message = ?
        if (upper.includes("SYNC_STATUS = 'ERROR'")) {
          const errMsg = String(params[0]);
          const repoId = Number(params[1]);
          const repo = self.repos.get(repoId);
          if (repo) {
            repo.sync_status = 'error';
            repo.error_message = errMsg;
            repo.updated_at = new Date().toISOString();
          }
          return { changes: 1 };
        }

        // 4. INSERT INTO packages ... ON CONFLICT
        if (upper.startsWith('INSERT INTO PACKAGES')) {
          const [
            package_id, name, section, latest_version, description, maintainer,
            author, architecture, icon_url, download_url, min_ios, max_ios,
            compatibility_status, is_legacy, repo_id
          ] = params;

          const existing = self.packages.get(package_id);
          const pkgItem: PackageItem = {
            package_id,
            name: name || package_id,
            section: section || 'System Utilities',
            latest_version,
            description: description || '',
            maintainer: maintainer || 'Unknown',
            author: author || maintainer || 'Unknown',
            architecture: architecture || 'iphoneos-arm',
            icon_url: icon_url || existing?.icon_url || null,
            download_url: download_url || existing?.download_url || null,
            min_ios: min_ios !== undefined ? min_ios : existing?.min_ios || null,
            max_ios: max_ios !== undefined ? max_ios : existing?.max_ios || null,
            compatibility_status: compatibility_status || 'Reported',
            is_legacy: Number(is_legacy) || 0,
            repo_id: Number(repo_id),
            updated_at: new Date().toISOString()
          };

          self.packages.set(package_id, pkgItem);
          self.updateRepoCounts();
          return { changes: 1 };
        }

        // 5. INSERT INTO package_versions ... ON CONFLICT
        if (upper.startsWith('INSERT INTO PACKAGE_VERSIONS')) {
          const [
            package_id, version, download_url, size_bytes, md5sum, sha256,
            dependencies, conflicts, architecture, repo_id
          ] = params;

          const key = `${package_id}@${version}`;
          self.packageVersions.set(key, {
            package_id,
            version,
            download_url,
            size_bytes: Number(size_bytes) || 0,
            md5sum: md5sum || null,
            sha256: sha256 || null,
            dependencies: dependencies || '',
            conflicts: conflicts || null,
            architecture: architecture || 'iphoneos-arm',
            repo_id: Number(repo_id)
          });
          return { changes: 1 };
        }

        // 6. INSERT INTO import_logs
        if (upper.startsWith('INSERT INTO IMPORT_LOGS')) {
          let repo_id: number;
          let status: 'success' | 'error';
          let packages_imported: number | null = null;
          let error_message: string | null = null;

          if (upper.includes('ERROR_MESSAGE')) {
            repo_id = Number(params[0]);
            status = 'error';
            error_message = String(params[1]);
          } else {
            repo_id = Number(params[0]);
            status = 'success';
            packages_imported = Number(params[1]);
          }

          const repo = self.repos.get(repo_id);
          self.importLogs.unshift({
            id: self.nextLogId++,
            repo_id,
            repo_name: repo?.name || `Repo #${repo_id}`,
            status,
            packages_imported,
            error_message,
            created_at: new Date().toISOString()
          });

          // Cap logs at 500
          if (self.importLogs.length > 500) {
            self.importLogs.pop();
          }

          return { changes: 1 };
        }

        // 7. INSERT INTO repos (name, url, icon_url)
        if (upper.startsWith('INSERT INTO REPOS')) {
          const [name, url, icon_url] = params;
          const id = self.nextRepoId++;
          self.repos.set(id, {
            id,
            name: name || new URL(url).hostname,
            url,
            icon_url: icon_url || null,
            sync_status: 'idle',
            error_message: null,
            last_sync: null,
            package_count: 0,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          });
          return { lastInsertRowid: id, changes: 1 };
        }

        // 8. DELETE FROM repos WHERE id = ?
        if (upper.startsWith('DELETE FROM REPOS WHERE ID = ?')) {
          const id = Number(params[0]);
          self.repos.delete(id);
          // remove packages associated with repo
          for (const [pkgId, pkg] of self.packages.entries()) {
            if (pkg.repo_id === id) {
              self.packages.delete(pkgId);
            }
          }
          return { changes: 1 };
        }

        return { changes: 0 };
      }
    };
  }

  /**
   * Transaction executor
   */
  public transaction(fn: (arg: any) => void) {
    return (arg: any) => {
      try {
        fn(arg);
      } catch (err) {
        throw err;
      }
    };
  }

  // Helper directly for UI
  public getRepoById(id: number) {
    return this.repos.get(id);
  }

  public getPackagesByRepo(repoId: number) {
    return Array.from(this.packages.values()).filter(p => p.repo_id === repoId);
  }

  public getPackageWithVersions(pkgId: string) {
    const pkg = this.packages.get(pkgId);
    if (!pkg) return null;
    const versions = Array.from(this.packageVersions.values())
      .filter(v => v.package_id === pkgId)
      .sort((a, b) => b.version.localeCompare(a.version, undefined, { numeric: true, sensitivity: 'base' }));
    const repo = this.repos.get(pkg.repo_id);
    return { ...pkg, repo_name: repo?.name, versions };
  }
}

export const db = new DatabaseEngine();
