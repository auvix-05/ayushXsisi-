import type { Repo, PackageItem, ImportLog, SSRFResult } from './types.ts';
import { db } from './db.ts';
import { syncRepo } from './repo-sync.ts';
import { validateSafeUrl } from './ssrf.ts';
import { parseDebianControl, mapSectionToCategory, lintDebianControl } from './debian-parser.ts';

// Helper to determine if backend is available
async function isBackendOnline(): Promise<boolean> {
  try {
    const res = await fetch('/api/repos', { method: 'GET', signal: AbortSignal.timeout(1500) });
    return res.ok;
  } catch {
    return false;
  }
}

export const api = {
  async getRepos(): Promise<Repo[]> {
    try {
      const res = await fetch('/api/repos');
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {}
    // Fallback to local DB engine
    return db.prepare<Repo>('SELECT * FROM repos').all();
  },

  async addRepo(name: string, url: string, icon_url?: string): Promise<Repo> {
    try {
      const res = await fetch('/api/repos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, url, icon_url })
      });
      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Failed to add repository');
      }
      return json.data;
    } catch (err: any) {
      // Local fallback with SSRF check
      const check = await validateSafeUrl(url);
      if (!check.safe) throw new Error(`SSRF Block: ${check.reason}`);
      const res = db.prepare('INSERT INTO repos (name, url, icon_url) VALUES (?, ?, ?)').run(name || new URL(url).hostname, url, icon_url || null);
      const newlyAdded = db.prepare<Repo>('SELECT * FROM repos WHERE id = ?').get(res.lastInsertRowid);
      if (!newlyAdded) throw new Error('Repository could not be added');
      return newlyAdded;
    }
  },

  async deleteRepo(id: number): Promise<void> {
    try {
      await fetch(`/api/repos/${id}`, { method: 'DELETE' });
    } catch {}
    db.prepare('DELETE FROM repos WHERE id = ?').run(id);
  },

  async syncRepo(id: number): Promise<{ success: boolean; count?: number; source?: string; error?: string }> {
    try {
      const res = await fetch(`/api/repos/${id}/sync`, { method: 'POST' });
      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Sync failed');
      }
      return json;
    } catch (err: any) {
      // Run direct sync through repo-sync engine
      try {
        const result = await syncRepo(id);
        return result;
      } catch (localErr: any) {
        throw localErr;
      }
    }
  },

  async getPackages(filters: { search?: string; section?: string; repo_id?: string; architecture?: string; legacy?: string } = {}): Promise<PackageItem[]> {
    try {
      const params = new URLSearchParams();
      if (filters.search) params.set('search', filters.search);
      if (filters.section) params.set('section', filters.section);
      if (filters.repo_id) params.set('repo_id', filters.repo_id);
      if (filters.architecture) params.set('architecture', filters.architecture);
      if (filters.legacy !== undefined) params.set('legacy', filters.legacy);

      const res = await fetch(`/api/packages?${params.toString()}`);
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {}

    // Fallback to local db query
    let list = db.prepare('SELECT * FROM packages').all() as PackageItem[];
    if (filters.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(p =>
        p.package_id.toLowerCase().includes(q) ||
        p.name.toLowerCase().includes(q) ||
        p.maintainer.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
      );
    }
    if (filters.section && filters.section !== 'all') {
      list = list.filter(p => p.section === filters.section);
    }
    if (filters.repo_id && filters.repo_id !== 'all') {
      const rid = Number(filters.repo_id);
      list = list.filter(p => p.repo_id === rid);
    }
    if (filters.architecture && filters.architecture !== 'all') {
      list = list.filter(p => p.architecture === filters.architecture);
    }
    if (filters.legacy && filters.legacy !== 'all') {
      const isLeg = filters.legacy === '1' ? 1 : 0;
      list = list.filter(p => p.is_legacy === isLeg);
    }
    return list;
  },

  async getPackage(id: string): Promise<PackageItem | null> {
    try {
      const res = await fetch(`/api/packages/${encodeURIComponent(id)}`);
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {}
    return db.getPackageWithVersions(id);
  },

  async parseControl(text: string) {
    try {
      const res = await fetch('/api/parse-control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text })
      });
      if (res.ok) {
        return await res.json();
      }
    } catch {}

    const parsed = parseDebianControl(text);
    const lint = lintDebianControl(text);
    const enriched = parsed.map(p => ({
      ...p,
      mappedCategory: mapSectionToCategory(p['section'] || '')
    }));
    return { success: true, count: enriched.length, packages: enriched, lint };
  },

  async testSsrf(url: string): Promise<SSRFResult> {
    try {
      const res = await fetch('/api/ssrf/audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {}
    return await validateSafeUrl(url);
  },

  async getLogs(): Promise<ImportLog[]> {
    try {
      const res = await fetch('/api/logs');
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch {}
    return db.prepare<ImportLog>('SELECT * FROM import_logs').all();
  }
};
