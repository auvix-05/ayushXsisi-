/**
 * Repository Synchronization Engine
 * Handles gzip decompression, Debian RFC822 control stream parsing,
 * SSRF validation, and database transaction updates.
 */

import { ungzip } from 'pako';
import type { Repo } from './types.ts';
import { validateSafeUrl } from './ssrf.ts';
import { db } from './db.ts';
import { parseDebianControl, mapSectionToCategory } from './debian-parser.ts';

/**
 * Downloads with custom timeout and strict byte length cap to protect server resources.
 */
export async function fetchSafeStream(url: string, maxBytes = 25 * 1024 * 1024): Promise<Uint8Array> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000); // 20s cap

  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'ayusXsisi-Cydia-Core/1.0 (Debian-APT; Security-Audited)'
      }
    });

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}: ${res.statusText}`);
    }

    const arrayBuffer = await res.arrayBuffer();
    if (arrayBuffer.byteLength > maxBytes) {
      throw new Error(`Response exceeded maximum permitted size of ${maxBytes} bytes.`);
    }

    return new Uint8Array(arrayBuffer);
  } finally {
    clearTimeout(timeout);
  }
}

/**
 * Imports or updates an APT Repo.
 * @param repoId number
 */
export async function syncRepo(repoId: number) {
  const repo = db.prepare<Repo>('SELECT * FROM repos WHERE id = ?').get(repoId);
  if (!repo) throw new Error('Repo not found.');

  db.prepare("UPDATE repos SET sync_status = 'syncing', error_message = NULL WHERE id = ?").run(repoId);

  try {
    const baseUrl = repo.url.endsWith('/') ? repo.url : repo.url + '/';

    // SSRF verification
    const ssrfCheck = await validateSafeUrl(baseUrl);
    if (!ssrfCheck.safe) {
      throw new Error(`SSRF Prevention Block: ${ssrfCheck.reason}`);
    }

    // Attempt index resolution in order: Packages.gz, then uncompressed Packages
    let packageDataText: string | null = null;
    let fetchedFrom: string | null = null;

    try {
      const gzUrl = baseUrl + 'Packages.gz';
      const gzBuffer = await fetchSafeStream(gzUrl);
      const decompressedBytes = ungzip(gzBuffer);
      const decoder = new TextDecoder('utf-8');
      packageDataText = decoder.decode(decompressedBytes);
      fetchedFrom = gzUrl;
    } catch (gzErr: any) {
      // Fallback to uncompressed Packages
      try {
        const plainUrl = baseUrl + 'Packages';
        const buffer = await fetchSafeStream(plainUrl);
        const decoder = new TextDecoder('utf-8');
        packageDataText = decoder.decode(buffer);
        fetchedFrom = plainUrl;
      } catch (plainErr: any) {
        throw new Error(`Failed to retrieve APT indexes (Packages.gz: ${gzErr.message}; Packages: ${plainErr.message})`);
      }
    }

    if (!packageDataText) {
      throw new Error('Index returned empty payload.');
    }

    const rawPackages = parseDebianControl(packageDataText);
    if (rawPackages.length === 0) {
      throw new Error('Index retrieved successfully, but parsed 0 valid Debian packages.');
    }

    const insertPkgStmt = db.prepare(`
      INSERT INTO packages (
        package_id, name, section, latest_version, description, maintainer,
        author, architecture, icon_url, download_url, min_ios, max_ios,
        compatibility_status, is_legacy, repo_id, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(package_id) DO UPDATE SET
        latest_version = excluded.latest_version,
        name = excluded.name,
        section = excluded.section,
        description = excluded.description,
        download_url = excluded.download_url,
        architecture = excluded.architecture,
        updated_at = CURRENT_TIMESTAMP
    `);

    const insertVerStmt = db.prepare(`
      INSERT INTO package_versions (
        package_id, version, download_url, size_bytes, md5sum, sha256,
        dependencies, conflicts, architecture, repo_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(package_id, version) DO UPDATE SET
        download_url = excluded.download_url,
        dependencies = excluded.dependencies,
        conflicts = excluded.conflicts
    `);

    // Run transaction
    let importedCount = 0;
    const runTransaction = db.transaction((packages: Array<Record<string, string>>) => {
      for (const p of packages) {
        const pkgIdentifier = p['package'];
        const version = p['version'];
        const name = p['name'] || pkgIdentifier;
        const section = mapSectionToCategory(p['section']);
        const description = p['description'] || 'No description provided by maintainer.';
        const maintainer = p['maintainer'] || p['author'] || 'Unknown Maintainer';
        const architecture = p['architecture'] || 'iphoneos-arm';
        const icon = p['icon'] || null;

        // Download location assembly
        let downloadUrl: string | null = null;
        if (p['filename']) {
          downloadUrl = p['filename'].startsWith('http')
            ? p['filename']
            : baseUrl + p['filename'].replace(/^\.?\//, '');
        }

        // Infer legacy iOS flags
        const depends = p['depends'] || '';
        const isLegacy = depends.includes('firmware (<=') || section === 'Legacy Packages' || architecture === 'iphoneos-arm' ? 1 : 0;

        insertPkgStmt.run(
          pkgIdentifier, name, section, version, description,
          maintainer, maintainer, architecture, icon, downloadUrl,
          null, null, 'Reported', isLegacy, repoId
        );

        insertVerStmt.run(
          pkgIdentifier, version, downloadUrl,
          p['size'] ? parseInt(p['size'], 10) : 0,
          p['md5sum'] || null, p['sha256'] || null,
          depends, p['conflicts'] || null, architecture, repoId
        );

        importedCount++;
      }
    });

    runTransaction(rawPackages);

    // Update Repo status
    db.prepare(`
      UPDATE repos 
      SET last_sync = CURRENT_TIMESTAMP, sync_status = 'success', error_message = NULL, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(repoId);

    // Log success
    db.prepare(`
      INSERT INTO import_logs (repo_id, status, packages_imported)
      VALUES (?, 'success', ?)
    `).run(repoId, importedCount);

    return { success: true, count: importedCount, source: fetchedFrom };
  } catch (err: any) {
    db.prepare(`
      UPDATE repos 
      SET sync_status = 'error', error_message = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(err.message, repoId);

    db.prepare(`
      INSERT INTO import_logs (repo_id, status, error_message)
      VALUES (?, 'error', ?)
    `).run(repoId, err.message);

    throw err;
  }
}

export { parseDebianControl, mapSectionToCategory };
