export interface Repo {
  id: number;
  name: string;
  url: string;
  icon_url: string | null;
  sync_status: 'idle' | 'syncing' | 'success' | 'error';
  error_message: string | null;
  last_sync: string | null;
  package_count?: number;
  created_at: string;
  updated_at: string;
}

export interface PackageItem {
  package_id: string;
  name: string;
  section: string;
  latest_version: string;
  description: string;
  maintainer: string;
  author: string;
  architecture: string;
  icon_url: string | null;
  download_url: string | null;
  min_ios: string | null;
  max_ios: string | null;
  compatibility_status: string;
  is_legacy: number;
  repo_id: number;
  repo_name?: string;
  updated_at: string;
  versions?: PackageVersion[];
}

export interface PackageVersion {
  package_id: string;
  version: string;
  download_url: string | null;
  size_bytes: number;
  md5sum: string | null;
  sha256: string | null;
  dependencies: string;
  conflicts: string | null;
  architecture: string;
  repo_id: number;
}

export interface ImportLog {
  id: number;
  repo_id: number;
  repo_name?: string;
  status: 'success' | 'error';
  packages_imported: number | null;
  error_message: string | null;
  created_at: string;
}

export interface SSRFResult {
  safe: boolean;
  reason?: string;
  ip?: string;
  hostname?: string;
  protocol?: string;
}

export interface DebianControlMap {
  [key: string]: string;
}
