import React from 'react';
import { ShieldCheck, Play, ArrowRight, Terminal, Cpu, FileCode, CheckCircle2 } from 'lucide-react';

interface HeroSectionProps {
  onExploreDemo: () => void;
  onViewSpecs: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onExploreDemo, onViewSpecs }) => {
  return (
    <section className="relative pt-12 pb-16 md:pt-20 md:pb-24 overflow-hidden border-b border-slate-800/80">
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[350px] bg-gradient-to-b from-sky-500/10 via-indigo-500/5 to-transparent blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Value Proposition & Copy */}
          <div className="lg:col-span-7 space-y-6">
            {/* Trust Kicker without static pill boxes */}
            <div className="flex items-center gap-2 text-xs text-sky-400 font-mono tracking-wide">
              <span>Debian Policy Manual 5.1</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>iOS 10.0 – 27.0 (Cydia / Phoenix)</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Security-Audited Core</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white leading-[1.15] text-balance">
              The Security-Audited Debian APT Engine & Package Ecosystem
            </h1>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl font-sans">
              High-performance RFC822 multiline control parser, streaming <code className="text-sky-300 font-mono text-sm">Packages.gz</code> decompression with <code className="text-sky-300 font-mono text-sm">pako</code>, and zero-trust SSRF protection for iOS 10 to 27 jailbreak tweaks requiring Cydia or Phoenix.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onExploreDemo}
                className="flex items-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-sky-500 hover:bg-sky-400 rounded-lg shadow-lg shadow-sky-500/20 transition-all cursor-pointer whitespace-nowrap"
              >
                <span>Launch Interactive Sandbox</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onViewSpecs}
                className="flex items-center gap-2 px-5 py-3 text-sm font-medium text-slate-200 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                <Terminal className="w-4 h-4 text-sky-400" />
                <span>View Architecture Specs</span>
              </button>
            </div>

            {/* Architectural Trust Points */}
            <div className="pt-4 flex flex-wrap items-center gap-6 text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>iOS 10 – 27 (Requires Jailbreak via Cydia / Phoenix)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>RFC 1918 / 3927 Subnet Isolation</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>25MB Stream Safety Cap</span>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Engine Showcase Card with Brand Logo */}
          <div className="lg:col-span-5">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden backdrop-blur">
              {/* Subtle accent glow */}
              <div className="absolute top-0 right-0 w-48 h-48 bg-sky-500/10 blur-2xl rounded-full pointer-events-none" />

              <div className="flex items-center gap-4 pb-5 border-b border-slate-800">
                <div className="w-14 h-14 rounded-xl overflow-hidden border-2 border-slate-700 bg-white shadow-md flex items-center justify-center shrink-0">
                  <img
                    src="/assets/aistudio/image_1779022121296_31f14b66.jpg"
                    alt="ayusXsisi APT Core"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white tracking-tight">ayusXsisi-Cydia-Core</h3>
                  <div className="font-mono text-xs text-sky-400 mt-0.5">Version 1.0 (Debian-APT; Security-Audited)</div>
                  <div className="text-[11px] text-slate-400 mt-1">Autonomous APT Repository Engine</div>
                </div>
              </div>

              {/* Status specifications */}
              <div className="py-4 space-y-3 font-mono text-xs">
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950/70 border border-slate-850">
                  <span className="text-slate-400">Control Parser</span>
                  <span className="text-emerald-400 font-semibold">RFC822 Multiline Folding</span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950/70 border border-slate-850">
                  <span className="text-slate-400">SSRF Matrix</span>
                  <span className="text-emerald-400 font-semibold">IANA RFC 1918 Guard Active</span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950/70 border border-slate-850">
                  <span className="text-slate-400">Decompression</span>
                  <span className="text-sky-300 font-semibold">pako.ungzip (25MB Cap)</span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950/70 border border-slate-850">
                  <span className="text-slate-400">Target Platforms</span>
                  <span className="text-amber-300 text-right text-[11px]">iOS 10.0 – 27.0 (Cydia / Phoenix)</span>
                </div>
              </div>

              {/* Action trigger */}
              <button
                onClick={onExploreDemo}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-200 hover:text-white rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-2 cursor-pointer border border-slate-700/80"
              >
                <span>Test Live Control Parser & SSRF Matrix</span>
                <ArrowRight className="w-3.5 h-3.5 text-sky-400" />
              </button>
            </div>
          </div>
        </div>

        {/* Full-width Metric Strip below hero split */}
        <div className="mt-14 pt-8 border-t border-slate-800/80 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div>
            <div className="text-xs font-medium text-slate-400">Stream Resource Cap</div>
            <div className="mt-1 text-2xl font-bold text-white font-mono tabular-nums">25 MB</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Strict DoS prevention limit</div>
          </div>
          <div>
            <div className="text-xs font-medium text-slate-400">Network Isolation</div>
            <div className="mt-1 text-2xl font-bold text-emerald-400 font-mono tabular-nums">100%</div>
            <div className="text-[11px] text-slate-500 mt-0.5">RFC 1918 & 3927 shielded</div>
          </div>
          <div>
            <div className="text-xs font-medium text-slate-400">Control Parse Speed</div>
            <div className="mt-1 text-2xl font-bold text-sky-400 font-mono tabular-nums">&lt; 12 ms</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Optimized folded line AST</div>
          </div>
          <div>
            <div className="text-xs font-medium text-slate-400">Preloaded Repositories</div>
            <div className="mt-1 text-2xl font-bold text-white font-mono tabular-nums">4 Sources</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Chariz, Havoc, Procursus, opa334</div>
          </div>
        </div>
      </div>
    </section>
  );
};
