import React, { useState, useEffect } from 'react';
import { Globe, ShieldCheck, ShieldAlert, Loader2, CheckCircle2, Send, Plus } from 'lucide-react';
import { api } from '../lib/api.ts';
import type { SSRFResult } from '../lib/types.ts';

interface SubmitRepoSectionProps {
  onRepoAdded: () => void;
}

export const SubmitRepoSection: React.FC<SubmitRepoSectionProps> = ({ onRepoAdded }) => {
  const [url, setUrl] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [ssrfStatus, setSsrfStatus] = useState<SSRFResult | null>(null);
  const [checkingSsrf, setCheckingSsrf] = useState(false);

  useEffect(() => {
    if (!url.trim() || !url.startsWith('http')) {
      setSsrfStatus(null);
      return;
    }

    const timer = setTimeout(async () => {
      setCheckingSsrf(true);
      try {
        const result = await api.testSsrf(url.trim());
        setSsrfStatus(result);
      } catch {
        setSsrfStatus({ safe: false, reason: 'Security check service unreachable' });
      } finally {
        setCheckingSsrf(false);
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [url]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim() || (ssrfStatus && !ssrfStatus.safe)) return;

    setLoading(true);
    setError(null);

    try {
      await api.addRepo(name.trim() || undefined as any, url.trim());
      setSuccess(true);
      onRepoAdded();
    } catch (err: any) {
      setError(err.message || 'Failed to submit repository');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setUrl('');
    setName('');
    setEmail('');
    setNotes('');
    setError(null);
    setSuccess(false);
    setSsrfStatus(null);
  };

  return (
    <section id="submit-repo" className="py-20 border-b border-slate-800/80 bg-slate-950/60">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="text-xs font-semibold text-sky-400 font-mono tracking-wide uppercase">
            Repository Onboarding
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-2">
            Submit an APT Repository for Security Auditing
          </h2>
          <p className="text-sm text-slate-400 mt-2 leading-relaxed">
            Register your community tweak source or corporate package registry. Every submission is subjected to real-time SSRF isolation and Debian RFC822 validation.
          </p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-10 shadow-2xl backdrop-blur">
          {success ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-12 h-12 bg-emerald-950/80 border border-emerald-800 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">Repository Registered Successfully</h3>
              <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                Your repository has passed the SSRF firewall pre-flight check and has been indexed into the ayusXsisi APT database.
              </p>
              <button
                onClick={handleReset}
                className="mt-4 px-5 py-2 text-xs font-semibold text-white bg-sky-500 hover:bg-sky-400 rounded-lg transition-colors cursor-pointer"
              >
                Submit Another Repository
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              {error && (
                <div className="p-3.5 bg-red-950/60 border border-red-800/80 rounded-lg text-xs text-red-200">
                  {error}
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  APT Repository Base URL <span className="text-sky-400">*</span>
                </label>
                <div className="relative">
                  <Globe className="w-4 h-4 text-slate-500 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="url"
                    required
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="https://repo.example.com/"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white placeholder-slate-500 font-mono focus:outline-none focus:border-sky-500"
                  />
                </div>

                {/* Realtime SSRF feedback */}
                {checkingSsrf && (
                  <div className="flex items-center gap-1.5 mt-2 text-xs text-slate-400">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-sky-400" />
                    <span>Evaluating target URL against RFC 1918 / 3927 SSRF policies...</span>
                  </div>
                )}

                {!checkingSsrf && ssrfStatus && (
                  <div
                    className={`flex items-start gap-2 mt-2.5 p-2.5 rounded-lg text-xs ${
                      ssrfStatus.safe
                        ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-800/50'
                        : 'bg-red-950/40 text-red-300 border border-red-800/50'
                    }`}
                  >
                    {ssrfStatus.safe ? (
                      <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <div className="font-semibold">
                        {ssrfStatus.safe ? 'Target Approved: Public Endpoint Verified' : 'Submission Blocked: Security Exception'}
                      </div>
                      <div className="text-[11px] opacity-90 mt-0.5">
                        {ssrfStatus.reason || `Target host resolved to safe external IP: ${ssrfStatus.ip}`}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Repository Name (Optional)
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Acme Tweak Labs"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Maintainer Contact Email
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="maintainer@example.com"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Registry Description & Compatibility Notes
                </label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Provide architecture details (e.g. Supports iOS 10.0 – 27.0; Requires Jailbreak via Cydia or Phoenix)..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 resize-none font-sans"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading || (ssrfStatus !== null && !ssrfStatus.safe)}
                  className="w-full py-3 text-xs font-semibold text-white bg-sky-500 hover:bg-sky-400 disabled:bg-slate-800 disabled:text-slate-500 rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  {loading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>Submit Repository for Immediate Indexing</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};
