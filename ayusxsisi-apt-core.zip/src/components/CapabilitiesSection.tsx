import React from 'react';
import { Layers, ShieldCheck, Cpu, Database, Check } from 'lucide-react';

export const CapabilitiesSection: React.FC = () => {
  const capabilities = [
    {
      index: '01',
      title: 'Debian RFC822 Control Parsing & Normalization',
      description:
        'Full compliance with Debian Policy Manual section 5.1. Correctly decodes paragraph continuations starting with spaces or tabs, multiline package descriptions, and custom maintainer metadata.',
      highlights: [
        'Multiline folded field state engine',
        'Automatic category classification across 10 taxonomy groups',
        'Syntax verification & package naming linting',
        'Version history & architectural mapping'
      ]
    },
    {
      index: '02',
      title: 'Zero-Trust SSRF & DNS Rebinding Defense',
      description:
        'Guarantees that outbound APT index requests can never be weaponized to probe internal microservices, private VPCs, or cloud provider instance metadata endpoints.',
      highlights: [
        'RFC 1918 Private IPv4 address space rejection',
        'RFC 3927 Link-Local & AWS/GCP metadata blocking',
        'RFC 1122 Loopback interface isolation',
        'DNS resolution inspection preventing rebinding'
      ]
    },
    {
      index: '03',
      title: 'Streaming Packages.gz Decompression Engine',
      description:
        'High-efficiency in-memory stream pipeline utilizing pako. Automatically negotiates compressed Packages.gz index streams with transparent fallback to raw uncompressed Packages.',
      highlights: [
        '25MB strict byte cap preventing memory exhaustion',
        '20-second hard request execution timeout',
        'Audited User-Agent: ayusXsisi-Cydia-Core/1.0',
        'Atomic database transactions for package upserts'
      ]
    },
    {
      index: '04',
      title: 'Multi-Architectural Tweak & Binary Registry',
      description:
        'Designed specifically for the iOS jailbreak and Debian tweak ecosystem across iOS 10 through iOS 27, tracking 64-bit and 32-bit architectures requiring Cydia or Phoenix environments.',
      highlights: [
        'iOS 10.0 through iOS 27.0+ compatibility enforcement',
        'Mandatory jailbreak via Cydia or Phoenix bootstrap',
        'Dependency graph resolution (Substrate, ElleKit, PreferenceLoader)',
        'Direct Cydia, Sileo, and Zebra package manager URL schemes'
      ]
    }
  ];

  return (
    <section id="capabilities" className="py-20 border-b border-slate-800/80">
      <div id="security-matrix" className="max-w-7xl mx-auto px-6">
        <div className="max-w-2xl mb-14">
          <div className="text-xs font-semibold text-sky-400 font-mono tracking-wide uppercase">
            System Capabilities
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-2">
            Engineered for High-Reliability APT Synchronization
          </h2>
          <p className="text-sm text-slate-400 mt-2 leading-relaxed">
            Every component in ayusXsisi APT Core is architected from first principles to process untrusted community repositories with mathematical rigor and zero compromise.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {capabilities.map((cap) => (
            <div
              key={cap.index}
              className="bg-slate-900/60 border border-slate-800 rounded-xl p-7 hover:border-slate-700/80 transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="text-xs font-mono font-semibold text-sky-400 mb-2">
                  {cap.index}. CAPABILITY
                </div>
                <h3 className="text-lg font-bold text-white tracking-tight mb-3">
                  {cap.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans mb-6">
                  {cap.description}
                </p>
              </div>

              <div className="pt-5 border-t border-slate-800/80 space-y-2">
                {cap.highlights.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-xs text-slate-400">
                    <Check className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
