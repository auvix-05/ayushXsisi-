import React, { useState, useEffect, useRef } from 'react';
import {
  Terminal as TerminalIcon,
  ChevronDown,
  ChevronUp,
  Maximize2,
  Minimize2,
  X,
  Play,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Circle
} from 'lucide-react';
import type { Repo, PackageItem } from '../lib/types.ts';
import { api } from '../lib/api.ts';

interface StatusTerminalProps {
  repos: Repo[];
  onRefreshRepos: () => void;
}

interface LogEntry {
  id: string;
  timestamp: string;
  type: 'system' | 'info' | 'success' | 'warn' | 'command';
  text: string;
}

export const StatusTerminal: React.FC<StatusTerminalProps> = ({ repos, onRefreshRepos }) => {
  const [isOpen, setIsOpen] = useState(true);
  const [isMinimized, setIsMinimized] = useState(false);
  const [command, setCommand] = useState('');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const logsEndRef = useRef<HTMLDivElement>(null);

  const totalPackages = repos.reduce((acc, r) => acc + (r.package_count || 0), 0);

  const addLog = (text: string, type: LogEntry['type'] = 'info') => {
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];
    setLogs(prev => [
      ...prev.slice(-100), // Keep last 100 entries
      {
        id: Math.random().toString(36).substring(2, 9),
        timestamp: timeStr,
        type,
        text
      }
    ]);
  };

  // Initial boot sequence
  useEffect(() => {
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];
    setLogs([
      {
        id: 'boot-1',
        timestamp: timeStr,
        type: 'system',
        text: 'ayusXsisi-Cydia-Core/1.0 daemon online (Debian-APT; Security-Audited)'
      },
      {
        id: 'boot-2',
        timestamp: timeStr,
        type: 'info',
        text: `Active APT Sources: ${repos.length} configured | Indexed Tweaks: ${totalPackages}`
      },
      {
        id: 'boot-3',
        timestamp: timeStr,
        type: 'success',
        text: 'Target Platforms: iOS 10.0 – 27.0 (Requires Jailbreak via Cydia / Phoenix)'
      },
      {
        id: 'boot-4',
        timestamp: timeStr,
        type: 'info',
        text: 'SSRF Firewall: RFC 1918 / RFC 3927 enforced. Type "help/" for available commands.'
      }
    ]);
  }, [repos.length]);

  // Auto scroll to bottom
  useEffect(() => {
    if (!isMinimized && logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, isMinimized]);

  const handleCommandSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const rawInput = command.trim();
    if (!rawInput) return;

    // Normalize command to ensure / ending form is shown in log
    const displayCmd = rawInput.endsWith('/') ? rawInput : `${rawInput}/`;
    addLog(`$ ${displayCmd}`, 'command');
    setCommand('');

    // Tokenize command and strip slashes for matching
    const parts = rawInput.toLowerCase().split(/\s+/);
    const root = parts[0].replace(/^\/+/, '').replace(/\/+$/, '');
    const arg = parts[1] ? parts[1].replace(/^\/+/, '').replace(/\/+$/, '') : undefined;

    switch (root) {
      case 'help':
        addLog('Available terminal commands (run with / ending):', 'system');
        addLog('  status/     - Print ecosystem status and security state', 'info');
        addLog('  repos/      - List registered APT repositories & sync state', 'info');
        addLog('  tweaks/     - Display indexed packages & compatibility', 'info');
        addLog('  sync/ [id]  - Trigger live synchronization on repo ID', 'info');
        addLog('  ssrf/       - Check SSRF protection policy details', 'info');
        addLog('  clear/      - Clear terminal display buffer', 'info');
        break;

      case 'status':
        addLog(`[STATUS/] Repositories: ${repos.length} registered`, 'info');
        addLog(`[STATUS/] Total Tweaks: ${totalPackages} indexed`, 'info');
        addLog('[STATUS/] Firmware: iOS 10.0 - 27.0 (Jailbreak via Cydia / Phoenix mandatory)', 'success');
        addLog('[STATUS/] Engine: pako 2.1.0 gzip streamer (25MB cap, 20s timeout)', 'info');
        addLog('[STATUS/] SSRF Matrix: RFC 1918 / 3927 / 1122 isolated', 'success');
        break;

      case 'repos':
        addLog(`Configured APT Repositories (${repos.length}):`, 'system');
        repos.forEach(r => {
          addLog(`  #${r.id} ${r.name.padEnd(22)} | ${r.sync_status.toUpperCase()} | ${r.package_count || 0} tweaks/`, 'info');
        });
        break;

      case 'tweaks':
        addLog('Querying local tweak index...', 'info');
        try {
          const pkgs = await api.getPackages();
          addLog(`Indexed Tweaks (${pkgs.length} packages total):`, 'system');
          pkgs.slice(0, 6).forEach(p => {
            addLog(`  • ${p.name} (v${p.latest_version}) - ${p.package_id} [iOS 10-27 Cydia/Phoenix]`, 'info');
          });
          if (pkgs.length > 6) {
            addLog(`  ...and ${pkgs.length - 6} more tweaks available in Package Explorer.`, 'info');
          }
        } catch (err: any) {
          addLog(`Failed to query tweak index: ${err.message}`, 'warn');
        }
        break;

      case 'sync':
        const targetId = arg ? parseInt(arg, 10) : repos[0]?.id;
        if (!targetId || isNaN(targetId)) {
          addLog('Usage: sync/ <repo_id> (e.g. sync/ 1 or sync 1/)', 'warn');
          break;
        }
        const targetRepo = repos.find(r => r.id === targetId);
        addLog(`[SYNC/] Connecting to repo #${targetId} (${targetRepo?.name || 'Unknown'})...`, 'info');
        addLog('[SYNC/] Auditing target URL against SSRF firewall...', 'info');
        try {
          const res = await api.syncRepo(targetId);
          addLog(`[SYNC-SUCCESS/] Retrieved ${res.count || 0} packages via Packages.gz`, 'success');
          onRefreshRepos();
        } catch (err: any) {
          addLog(`[SYNC-ERROR/] ${err.message}`, 'warn');
        }
        break;

      case 'ssrf':
        addLog('SSRF Firewall Policy Status:', 'system');
        addLog('  • Loopback: 127.0.0.0/8, ::1 [BLOCKED]', 'success');
        addLog('  • Private: 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16 [BLOCKED]', 'success');
        addLog('  • Cloud Metadata: 169.254.169.254, metadata.google.internal [BLOCKED]', 'success');
        addLog('  • User-Agent: ayusXsisi-Cydia-Core/1.0 [ENFORCED]', 'info');
        break;

      case 'clear':
        setLogs([]);
        break;

      default:
        addLog(`Unknown command: "${rawInput}". Run with / ending, e.g. "help/", "status/", "repos/", "tweaks/".`, 'warn');
        break;
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="absolute top-24 right-4 sm:right-6 z-30 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-700/80 text-[11px] font-mono text-slate-200 shadow-xl hover:border-sky-500 hover:text-white transition-all cursor-pointer backdrop-blur"
      >
        <span className="relative flex h-1.5 w-1.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
        </span>
        <TerminalIcon className="w-3.5 h-3.5 text-sky-400" />
        <span>APT Terminal</span>
      </button>
    );
  }

  return (
    <aside
      aria-label="APT Status Terminal"
      className={`absolute top-24 right-4 sm:right-6 z-30 transition-all duration-300 font-mono shadow-xl ${
        isMinimized
          ? 'w-[240px] sm:w-[260px]'
          : 'w-[280px] sm:w-[310px]'
      }`}
    >
      <div className="bg-[#070b13]/95 border border-slate-800 rounded-lg overflow-hidden backdrop-blur-md shadow-xl flex flex-col text-[11px]">
        {/* Terminal Title Bar */}
        <div className="px-2.5 py-1.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between select-none">
          <div className="flex items-center gap-1.5">
            <span className="relative flex h-1.5 w-1.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
            </span>
            <TerminalIcon className="w-3 h-3 text-sky-400" />
            <span className="text-[11px] font-semibold text-slate-200 tracking-tight">
              APT Core Terminal
            </span>
          </div>

          <div className="flex items-center gap-1 text-slate-400">
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              title={isMinimized ? 'Expand' : 'Collapse'}
              className="p-0.5 hover:text-white transition-colors cursor-pointer"
            >
              {isMinimized ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
            <button
              onClick={() => setIsOpen(false)}
              title="Close Terminal"
              className="p-0.5 hover:text-red-400 transition-colors cursor-pointer"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Live status bar strip */}
        <div className="px-2.5 py-1 bg-slate-900/60 border-b border-slate-850 flex items-center justify-between text-[10px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-200 tabular-nums">{repos.length} Repos</span>
            <span>·</span>
            <span className="text-sky-300 tabular-nums">{totalPackages} Tweaks</span>
          </div>
          <div className="text-[9px] text-amber-300 truncate">
            iOS 10–27 (Cydia/Phoenix)
          </div>
        </div>

        {/* Terminal Body */}
        {!isMinimized && (
          <>
            <div className="p-2 text-[10px] leading-relaxed space-y-0.5 overflow-y-auto max-h-36 sm:max-h-40 select-text font-mono">
              {logs.map(log => (
                <div key={log.id} className="flex items-start gap-1">
                  <span className="text-slate-600 select-none tabular-nums text-[9px] shrink-0 pt-0.5">
                    [{log.timestamp}]
                  </span>
                  <span
                    className={
                      log.type === 'command'
                        ? 'text-sky-400 font-semibold'
                        : log.type === 'success'
                        ? 'text-emerald-400'
                        : log.type === 'warn'
                        ? 'text-red-300'
                        : log.type === 'system'
                        ? 'text-purple-300'
                        : 'text-slate-300'
                    }
                  >
                    {log.text}
                  </span>
                </div>
              ))}
              <div ref={logsEndRef} />
            </div>

            {/* Interactive Prompt Input */}
            <form
              onSubmit={handleCommandSubmit}
              className="px-2 py-1.5 bg-slate-950/80 border-t border-slate-800 flex items-center gap-1 text-[10px] font-mono"
            >
              <span className="text-emerald-400 select-none text-[10px]">cydia@core:/$</span>
              <input
                type="text"
                value={command}
                onChange={e => setCommand(e.target.value)}
                placeholder="status/, repos/, tweaks/..."
                className="flex-1 bg-transparent text-slate-200 placeholder-slate-600 focus:outline-none text-[10px]"
                spellCheck={false}
              />
              <button
                type="submit"
                className="text-slate-500 hover:text-sky-400 p-0.5 transition-colors cursor-pointer"
                title="Execute command"
              >
                <Play className="w-2.5 h-2.5" />
              </button>
            </form>
          </>
        )}
      </div>
    </aside>
  );
};
