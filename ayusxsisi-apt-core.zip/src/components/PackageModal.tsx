import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  Download,
  Terminal,
  ShieldCheck,
  Layers,
  FileText,
  Clock,
  ExternalLink
} from 'lucide-react';
import type { PackageItem } from '../lib/types.ts';

interface PackageModalProps {
  pkg: PackageItem | null;
  onClose: () => void;
}

export const PackageModal: React.FC<PackageModalProps> = ({ pkg, onClose }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'details' | 'control' | 'versions'>('details');

  if (!pkg) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const formatBytes = (bytes: number) => {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Generate standard RFC822 Debian control block
  const rawControlText = [
    `Package: ${pkg.package_id}`,
    `Name: ${pkg.name}`,
    `Version: ${pkg.latest_version}`,
    `Architecture: ${pkg.architecture}`,
    `Maintainer: ${pkg.maintainer}`,
    `Author: ${pkg.author}`,
    `Section: ${pkg.section}`,
    pkg.icon_url ? `Icon: ${pkg.icon_url}` : null,
    `Description: ${pkg.description.split('\n').join('\n ')}`,
    pkg.download_url ? `Filename: ${pkg.download_url}` : null,
    pkg.versions && pkg.versions[0]?.dependencies ? `Depends: ${pkg.versions[0].dependencies}` : null,
    pkg.versions && pkg.versions[0]?.conflicts ? `Conflicts: ${pkg.versions[0].conflicts}` : null,
    pkg.versions && pkg.versions[0]?.size_bytes ? `Size: ${pkg.versions[0].size_bytes}` : null,
    pkg.versions && pkg.versions[0]?.md5sum ? `MD5sum: ${pkg.versions[0].md5sum}` : null,
    pkg.versions && pkg.versions[0]?.sha256 ? `SHA256: ${pkg.versions[0].sha256}` : null,
  ].filter(Boolean).join('\n');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-800 flex items-start justify-between gap-4">
          <div className="flex items-start gap-4">
            {pkg.icon_url ? (
              <img
                src={pkg.icon_url}
                alt={pkg.name}
                referrerPolicy="no-referrer"
                className="w-14 h-14 rounded-xl object-contain bg-slate-950 border border-slate-800 p-1 shrink-0"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            ) : (
              <div className="w-14 h-14 rounded-xl bg-slate-800 flex items-center justify-center text-slate-200 font-bold text-xl shrink-0">
                {pkg.name.charAt(0).toUpperCase()}
              </div>
            )}

            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">{pkg.name}</h2>
                <span className="text-xs text-sky-400 font-mono font-medium">v{pkg.latest_version}</span>
              </div>
              
              <div className="text-xs text-slate-400 font-mono mt-0.5">{pkg.package_id}</div>

              {/* Clean unboxed metadata with · separators */}
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mt-2">
                <span className="text-slate-300">{pkg.section}</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="font-mono text-slate-300">{pkg.architecture}</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span>{pkg.repo_name || `Repo #${pkg.repo_id}`}</span>
                {pkg.is_legacy === 1 && (
                  <>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-amber-400 font-medium">Legacy 32-bit</span>
                  </>
                )}
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="px-6 border-b border-slate-800 flex items-center gap-6 text-xs font-medium text-slate-400">
          <button
            onClick={() => setActiveTab('details')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'details'
                ? 'border-sky-400 text-white font-semibold'
                : 'border-transparent hover:text-slate-200'
            }`}
          >
            Package Overview
          </button>
          <button
            onClick={() => setActiveTab('versions')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'versions'
                ? 'border-sky-400 text-white font-semibold'
                : 'border-transparent hover:text-slate-200'
            }`}
          >
            Versions & Checksums ({pkg.versions?.length || 1})
          </button>
          <button
            onClick={() => setActiveTab('control')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'control'
                ? 'border-sky-400 text-white font-semibold'
                : 'border-transparent hover:text-slate-200'
            }`}
          >
            Raw RFC822 Control
          </button>
        </div>

        {/* Modal content body */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-300">
          {activeTab === 'details' && (
            <>
              {/* Description */}
              <div>
                <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2">Description</h4>
                <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-lg whitespace-pre-wrap leading-relaxed text-slate-300 font-sans">
                  {pkg.description || 'No description provided in Debian control.'}
                </div>
              </div>

              {/* Metadata attributes */}
              <div className="grid grid-cols-2 gap-4 p-3.5 bg-slate-950/50 border border-slate-800 rounded-lg">
                <div>
                  <div className="text-[11px] text-slate-500">Maintainer</div>
                  <div className="text-xs font-medium text-slate-200 mt-0.5 truncate">{pkg.maintainer}</div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">Author</div>
                  <div className="text-xs font-medium text-slate-200 mt-0.5 truncate">{pkg.author}</div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">iOS Compatibility</div>
                  <div className="text-xs font-medium text-slate-200 mt-0.5">
                    iOS {pkg.min_ios || '10.0'} — {pkg.max_ios || '27.0'}
                  </div>
                  <div className="text-[10px] text-amber-300 font-mono mt-0.5">
                    Requires Jailbreak via Cydia / Phoenix
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500">Verification Status</div>
                  <div className="text-xs font-medium text-emerald-400 mt-0.5 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>{pkg.compatibility_status}</span>
                  </div>
                </div>
              </div>

              {/* Dependencies and Conflicts */}
              {pkg.versions && pkg.versions[0] && (
                <div className="space-y-3">
                  <div>
                    <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-1.5">Dependencies (Depends)</h4>
                    {pkg.versions[0].dependencies ? (
                      <div className="flex flex-wrap gap-1.5">
                        {pkg.versions[0].dependencies.split(',').map((dep, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-1 bg-slate-800/80 border border-slate-700/60 rounded text-[11px] font-mono text-slate-300"
                          >
                            {dep.trim()}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <div className="text-slate-500 italic">No external dependencies specified.</div>
                    )}
                  </div>

                  {pkg.versions[0].conflicts && (
                    <div>
                      <h4 className="text-xs font-semibold text-red-300 uppercase tracking-wider mb-1.5">Conflicts</h4>
                      <div className="flex flex-wrap gap-1.5">
                        {pkg.versions[0].conflicts.split(',').map((conf, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-1 bg-red-950/40 border border-red-900/60 rounded text-[11px] font-mono text-red-300"
                          >
                            {conf.trim()}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Installation commands */}
              <div className="space-y-2">
                <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">APT CLI & URL Schemes</h4>
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between font-mono text-xs">
                  <div className="flex items-center gap-2 text-slate-300 truncate">
                    <Terminal className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                    <span className="truncate">apt-get install {pkg.package_id}</span>
                  </div>
                  <button
                    onClick={() => handleCopy(`apt-get install ${pkg.package_id}`, 'apt')}
                    className="flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300 ml-2 shrink-0"
                  >
                    {copiedKey === 'apt' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'apt' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <a
                    href={`cydia://package/${pkg.package_id}`}
                    className="text-center py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-xs font-medium text-amber-300 hover:text-amber-200 transition-colors"
                  >
                    Open in Cydia
                  </a>
                  <a
                    href={`sileo://package/${pkg.package_id}`}
                    className="text-center py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-xs font-medium text-slate-200 transition-colors"
                  >
                    Open in Sileo
                  </a>
                  <a
                    href={`zbra://packages/${pkg.package_id}`}
                    className="text-center py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-xs font-medium text-slate-200 transition-colors"
                  >
                    Open in Zebra
                  </a>
                  {pkg.download_url && (
                    <a
                      href={pkg.download_url}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center justify-center gap-1.5 py-2 bg-sky-500 hover:bg-sky-400 text-white rounded-lg text-xs font-medium transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>.deb</span>
                    </a>
                  )}
                </div>
              </div>
            </>
          )}

          {activeTab === 'versions' && (
            <div className="space-y-4">
              <div className="text-xs text-slate-400">
                Audit and cryptographic validation hashes for all package version releases in the APT index:
              </div>

              <div className="border border-slate-800 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="px-3 py-2 font-medium">Version</th>
                      <th className="px-3 py-2 font-medium">Size</th>
                      <th className="px-3 py-2 font-medium">Architecture</th>
                      <th className="px-3 py-2 font-medium text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 font-mono">
                    {(pkg.versions && pkg.versions.length > 0 ? pkg.versions : [{
                      package_id: pkg.package_id,
                      version: pkg.latest_version,
                      download_url: pkg.download_url,
                      size_bytes: 0,
                      md5sum: null,
                      sha256: null,
                      dependencies: '',
                      conflicts: null,
                      architecture: pkg.architecture,
                      repo_id: pkg.repo_id
                    }]).map((ver) => (
                      <tr key={ver.version} className="hover:bg-slate-800/30">
                        <td className="px-3 py-2.5 text-white font-semibold">{ver.version}</td>
                        <td className="px-3 py-2.5 text-slate-300 tabular-nums">
                          {formatBytes(ver.size_bytes)}
                        </td>
                        <td className="px-3 py-2.5 text-slate-400">{ver.architecture}</td>
                        <td className="px-3 py-2.5 text-right font-sans">
                          {ver.download_url ? (
                            <a
                              href={ver.download_url}
                              target="_blank"
                              rel="noreferrer"
                              className="text-sky-400 hover:text-sky-300 inline-flex items-center gap-1 text-[11px]"
                            >
                              <span>deb</span>
                              <Download className="w-3 h-3" />
                            </a>
                          ) : (
                            <span className="text-slate-600 text-[11px]">N/A</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Checksum cards */}
              {pkg.versions && pkg.versions[0] && (
                <div className="space-y-2 pt-2">
                  <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Cryptographic Hashes</h4>
                  
                  {pkg.versions[0].sha256 && (
                    <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                      <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                        <span>SHA-256 Checksum</span>
                        <button
                          onClick={() => handleCopy(pkg.versions![0].sha256!, 'sha256')}
                          className="flex items-center gap-1 text-sky-400 hover:text-sky-300"
                        >
                          {copiedKey === 'sha256' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedKey === 'sha256' ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>
                      <div className="font-mono text-xs text-slate-300 break-all select-all">
                        {pkg.versions[0].sha256}
                      </div>
                    </div>
                  )}

                  {pkg.versions[0].md5sum && (
                    <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                      <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                        <span>MD5 Checksum</span>
                        <button
                          onClick={() => handleCopy(pkg.versions![0].md5sum!, 'md5')}
                          className="flex items-center gap-1 text-sky-400 hover:text-sky-300"
                        >
                          {copiedKey === 'md5' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedKey === 'md5' ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>
                      <div className="font-mono text-xs text-slate-300 break-all select-all">
                        {pkg.versions[0].md5sum}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {activeTab === 'control' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">
                  Debian RFC822 format generated for this package:
                </span>
                <button
                  onClick={() => handleCopy(rawControlText, 'raw-ctrl')}
                  className="flex items-center gap-1 text-xs text-sky-400 hover:text-sky-300"
                >
                  {copiedKey === 'raw-ctrl' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'raw-ctrl' ? 'Copied' : 'Copy Control'}</span>
                </button>
              </div>

              <pre className="p-4 bg-slate-950 border border-slate-800 rounded-lg font-mono text-xs text-slate-300 leading-relaxed overflow-x-auto select-all">
                {rawControlText}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
