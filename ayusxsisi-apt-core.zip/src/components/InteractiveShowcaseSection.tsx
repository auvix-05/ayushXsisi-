import React, { useState } from 'react';
import { Package, FileCode, Shield, RefreshCw } from 'lucide-react';
import { PackagesView } from './PackagesView.tsx';
import { ControlPlaygroundView } from './ControlPlaygroundView.tsx';
import { SsrfAuditorView } from './SsrfAuditorView.tsx';
import { RepositoriesView } from './RepositoriesView.tsx';
import { PackageModal } from './PackageModal.tsx';
import type { Repo, PackageItem } from '../lib/types.ts';
import { api } from '../lib/api.ts';

interface InteractiveShowcaseSectionProps {
  repos: Repo[];
  onRefreshRepos: () => void;
  onOpenAddModal: () => void;
}

export const InteractiveShowcaseSection: React.FC<InteractiveShowcaseSectionProps> = ({
  repos,
  onRefreshRepos,
  onOpenAddModal
}) => {
  const [activeTab, setActiveTab] = useState<'packages' | 'parser' | 'ssrf' | 'repos'>('packages');
  const [selectedPackage, setSelectedPackage] = useState<PackageItem | null>(null);

  const handleOpenPackageModal = async (pkg: PackageItem) => {
    try {
      const full = await api.getPackage(pkg.package_id);
      setSelectedPackage(full || pkg);
    } catch {
      setSelectedPackage(pkg);
    }
  };

  return (
    <section id="interactive-showcase" className="py-20 border-b border-slate-800/80 bg-slate-950/40">
      <div className="max-w-7xl mx-auto px-6 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-semibold text-sky-400 font-mono tracking-wide uppercase">
              Interactive Product Sandbox
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-2">
              Experience the Live APT Core Engine
            </h2>
            <p className="text-sm text-slate-400 mt-2 max-w-xl">
              Interact directly with the real Node.js RFC822 parser, SSRF validation suite, and SQLite APT package database running in real time.
            </p>
          </div>

          {/* Clean Segmented Tab Switcher */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-xl self-start md:self-auto overflow-x-auto max-w-full">
            <button
              onClick={() => setActiveTab('packages')}
              className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'packages'
                  ? 'bg-sky-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Package className="w-3.5 h-3.5" />
              <span>Package Explorer</span>
            </button>
            <button
              onClick={() => setActiveTab('parser')}
              className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'parser'
                  ? 'bg-sky-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>RFC822 Parser</span>
            </button>
            <button
              onClick={() => setActiveTab('ssrf')}
              className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'ssrf'
                  ? 'bg-sky-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>SSRF Firewall</span>
            </button>
            <button
              onClick={() => setActiveTab('repos')}
              className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'repos'
                  ? 'bg-sky-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Repository Sync</span>
            </button>
          </div>
        </div>

        {/* Sandbox Content Container */}
        <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-6 sm:p-8 backdrop-blur">
          {activeTab === 'packages' && (
            <PackagesView
              repos={repos}
              onSelectPackage={handleOpenPackageModal}
            />
          )}

          {activeTab === 'parser' && (
            <ControlPlaygroundView
              onPackageImported={() => {
                onRefreshRepos();
              }}
            />
          )}

          {activeTab === 'ssrf' && <SsrfAuditorView />}

          {activeTab === 'repos' && (
            <RepositoriesView
              repos={repos}
              onRefresh={onRefreshRepos}
              onOpenAddModal={onOpenAddModal}
              onSelectRepoForPackages={() => setActiveTab('packages')}
            />
          )}
        </div>
      </div>

      {/* Package Inspector Modal */}
      <PackageModal
        pkg={selectedPackage}
        onClose={() => setSelectedPackage(null)}
      />
    </section>
  );
};
