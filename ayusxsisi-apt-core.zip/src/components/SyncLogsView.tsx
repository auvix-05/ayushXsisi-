import React, { useState, useEffect } from 'react';
import {
  History,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Clock,
  Package
} from 'lucide-react';
import { api } from '../lib/api.ts';
import type { ImportLog } from '../lib/types.ts';

export const SyncLogsView: React.FC = () => {
  const [logs, setLogs] = useState<ImportLog[]>([]);
  const [loading, setLoading] = useState(true);

  const loadLogs = async () => {
    setLoading(true);
    try {
      const data = await api.getLogs();
      setLogs(data);
    } catch (err) {
      console.error('Failed to load logs:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, []);

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-white tracking-tight">Repository Synchronization Audit Trail</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Audit history of all APT repository synchronizations, gzip index decompression, and database transactions.
          </p>
        </div>

        <button
          onClick={loadLogs}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-850 hover:bg-slate-800 border border-slate-750 rounded-lg transition-colors cursor-pointer self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-sky-400' : ''}`} />
          <span>Refresh Logs</span>
        </button>
      </div>

      {loading ? (
        <div className="p-12 text-center text-slate-500 text-xs">
          Loading synchronization log history...
        </div>
      ) : logs.length === 0 ? (
        <div className="bg-slate-900/60 border border-dashed border-slate-800 rounded-xl p-12 text-center">
          <History className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <h3 className="text-sm font-semibold text-white">No import logs recorded</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Synchronize an APT repository to generate synchronization and indexing audit entries.
          </p>
        </div>
      ) : (
        <div className="border border-slate-800 rounded-xl bg-slate-900/80 overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="px-4 py-3 font-medium">Timestamp</th>
                <th className="px-4 py-3 font-medium">Target Repository</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Packages Indexed</th>
                <th className="px-4 py-3 font-medium">Result / Error Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-4 py-3 text-slate-400 font-mono tabular-nums whitespace-nowrap">
                    {new Date(log.created_at).toLocaleString()}
                  </td>
                  <td className="px-4 py-3 text-slate-200 font-medium whitespace-nowrap">
                    {log.repo_name || `Repo #${log.repo_id}`}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    {log.status === 'success' ? (
                      <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Success</span>
                      </span>
                    ) : (
                      <span className="flex items-center gap-1.5 text-red-400 font-medium">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>Failed</span>
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 font-mono tabular-nums text-slate-300">
                    {log.packages_imported !== null ? (
                      <span className="text-sky-400 font-semibold">{log.packages_imported}</span>
                    ) : (
                      <span className="text-slate-600">0</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-slate-300">
                    {log.error_message ? (
                      <span className="text-red-300 font-mono text-[11px] break-all">
                        {log.error_message}
                      </span>
                    ) : (
                      <span className="text-slate-400">
                        Packages.gz index parsed & upserted via transaction
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
