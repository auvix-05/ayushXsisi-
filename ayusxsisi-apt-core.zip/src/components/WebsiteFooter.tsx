import React from 'react';

export const WebsiteFooter: React.FC = () => {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-950 border-t border-slate-900 py-12 text-slate-400 text-xs font-sans">
      <div className="max-w-7xl mx-auto px-6 space-y-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl overflow-hidden border border-slate-800 bg-white shadow-sm flex items-center justify-center shrink-0">
              <img
                src="/assets/aistudio/image_1779022121296_31f14b66.jpg"
                alt="ayusXsisi APT Core Logo"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="text-sm font-bold text-white tracking-tight">ayusXsisi APT Core</div>
              <div className="text-[11px] text-slate-500 font-mono">Debian RFC822 Engine & SSRF Audited Infrastructure</div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-slate-400">
            <button onClick={() => scrollTo('capabilities')} className="hover:text-white transition-colors cursor-pointer">
              Capabilities
            </button>
            <button onClick={() => scrollTo('interactive-showcase')} className="hover:text-white transition-colors cursor-pointer">
              Live Sandbox
            </button>
            <button onClick={() => scrollTo('security-matrix')} className="hover:text-white transition-colors cursor-pointer">
              SSRF Defense
            </button>
            <button onClick={() => scrollTo('architecture-specs')} className="hover:text-white transition-colors cursor-pointer">
              Engine Specs
            </button>
            <button onClick={() => scrollTo('submit-repo')} className="hover:text-white transition-colors cursor-pointer">
              Submit Repo
            </button>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            © {new Date().getFullYear()} ayusXsisi APT Core. Compliant with Debian Policy Manual 5.1 & IANA RFC Standards.
          </div>
          <div className="flex items-center gap-4 font-mono">
            <span>RFC822 Multiline Folding</span>
            <span>·</span>
            <span>RFC 1918 Isolation</span>
            <span>·</span>
            <span>pako Gzip Engine</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
