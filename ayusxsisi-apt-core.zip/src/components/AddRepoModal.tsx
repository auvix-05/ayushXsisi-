import React, { useState, useEffect } from 'react';
import { X, ShieldCheck, ShieldAlert, Loader2, Globe } from 'lucide-react';
import { api } from '../lib/api.ts';
import type { SSRFResult } from '../lib/types.ts';

interface AddRepoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdded: () => void;
}

const POPULAR_REPOS = [
  { name: 'Chariz Official', url: 'https://repo.chariz.com/', icon: 'https://repo.chariz.com/CydiaIcon.png' },
  { name: 'Havoc Community', url: 'https://havoc.app/', icon: 'https://havoc.app/icons/icon.png' },
  { name: 'Procursus APT', url: 'https://apt.procurs.us/', icon: 'https://apt.procurs.us/CydiaIcon.png' },
  { name: 'opa334 Repo', url: 'https://opa334.github.io/', icon: 'https://opa334.github.io/CydiaIcon.png' },
  { name: 'ElleKit Official', url: 'https://ellekit.sexy/', icon: '' },
  { name: 'SparkDev Repo', url: 'https://sparkdev.me/', icon: '' },
];

export const AddRepoModal: React.FC<AddRepoModalProps> = ({ isOpen, onClose, onAdded }) => {
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const [iconUrl, setIconUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [ssrfStatus, setSsrfStatus] = useState<SSRFResult | null>(null);
  const [checkingSsrf, setCheckingSsrf] = useState(false);

  useEffect(() => {
    if (!url.trim() || !url.startsWith('http')) {
      setSsrfStatus(null);
      return;
    }

    const timer = setTimeout(async () => {
      setCheckingSsrf(true);
      try {
        const result = await api.testSsrf(url.trim());
        setSsrfStatus(result);
      } catch {
        setSsrfStatus({ safe: false, reason: 'Failed to run security validation' });
      } finally {
        setCheckingSsrf(false);
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [url]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;

    setLoading(true);
    setError(null);

    try {
      await api.addRepo(name.trim(), url.trim(), iconUrl.trim() || undefined);
      onAdded();
      setName('');
      setUrl('');
      setIconUrl('');
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to register repository');
    } finally {
      setLoading(false);
    }
  };

  const selectPreset = (preset: { name: string; url: string; icon: string }) => {
    setName(preset.name);
    setUrl(preset.url);
    setIconUrl(preset.icon);
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-lg overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-sky-400" />
            <h3 className="text-base font-semibold text-white">Add Debian APT Repository</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-950/60 border border-red-800/80 rounded-lg text-xs text-red-200">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Repository URL (APT Base Endpoint)
            </label>
            <input
              type="url"
              required
              placeholder="https://repo.example.com/"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 font-mono"
            />
            
            {/* Realtime SSRF status indicator */}
            {checkingSsrf && (
              <div className="flex items-center gap-1.5 mt-2 text-xs text-slate-400">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-sky-400" />
                <span>Auditing URL against SSRF policy...</span>
              </div>
            )}

            {!checkingSsrf && ssrfStatus && (
              <div className={`flex items-start gap-2 mt-2 p-2 rounded-md text-xs ${
                ssrfStatus.safe ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-800/50' : 'bg-red-950/40 text-red-300 border border-red-800/50'
              }`}>
                {ssrfStatus.safe ? (
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                )}
                <div>
                  <div className="font-semibold">{ssrfStatus.safe ? 'SSRF Safe: External Target Approved' : 'SSRF Alert: Request Blocked'}</div>
                  <div className="text-[11px] opacity-90 mt-0.5">{ssrfStatus.reason || `Target resolves to safe IP: ${ssrfStatus.ip}`}</div>
                </div>
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Repository Label / Name (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Chariz Official"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Icon URL (Optional)
            </label>
            <input
              type="url"
              placeholder="https://repo.example.com/CydiaIcon.png"
              value={iconUrl}
              onChange={(e) => setIconUrl(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
            />
          </div>

          {/* Quick presets */}
          <div>
            <div className="text-xs font-medium text-slate-400 mb-2">Or select a recognized community repository:</div>
            <div className="grid grid-cols-2 gap-1.5">
              {POPULAR_REPOS.map((preset) => (
                <button
                  type="button"
                  key={preset.url}
                  onClick={() => selectPreset(preset)}
                  className="px-2.5 py-1.5 text-xs text-left bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded text-slate-300 hover:text-white transition-colors truncate"
                >
                  {preset.name}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || (ssrfStatus !== null && !ssrfStatus.safe)}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-sky-500 hover:bg-sky-400 disabled:bg-slate-800 disabled:text-slate-500 rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              {loading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              <span>Add & Register</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
