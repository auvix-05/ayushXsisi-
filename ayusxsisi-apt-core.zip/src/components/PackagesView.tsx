import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  Package,
  Layers,
  ChevronRight,
  ShieldCheck,
  Smartphone,
  Cpu
} from 'lucide-react';
import type { PackageItem, Repo } from '../lib/types.ts';
import { api } from '../lib/api.ts';

interface PackagesViewProps {
  initialRepoFilter?: number | null;
  repos: Repo[];
  onSelectPackage: (pkg: PackageItem) => void;
}

const CATEGORIES = [
  'All Categories',
  'Customization and Themes',
  'Lock Screen',
  'Control Center',
  'Status Bar',
  'File Management',
  'Security and Privacy',
  'Productivity',
  'Development Tools',
  'Legacy Packages',
  'System Utilities',
];

export const PackagesView: React.FC<PackagesViewProps> = ({
  initialRepoFilter,
  repos,
  onSelectPackage
}) => {
  const [packages, setPackages] = useState<PackageItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedSection, setSelectedSection] = useState('All Categories');
  const [selectedRepoId, setSelectedRepoId] = useState<string>(
    initialRepoFilter ? String(initialRepoFilter) : 'all'
  );
  const [selectedArch, setSelectedArch] = useState('all');
  const [selectedLegacy, setSelectedLegacy] = useState('all');

  const loadPackages = async () => {
    setLoading(true);
    try {
      const data = await api.getPackages({
        search: search.trim() || undefined,
        section: selectedSection === 'All Categories' ? undefined : selectedSection,
        repo_id: selectedRepoId === 'all' ? undefined : selectedRepoId,
        architecture: selectedArch === 'all' ? undefined : selectedArch,
        legacy: selectedLegacy === 'all' ? undefined : selectedLegacy
      });
      setPackages(data);
    } catch (err) {
      console.error('Failed to load packages:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPackages();
  }, [search, selectedSection, selectedRepoId, selectedArch, selectedLegacy]);

  return (
    <div className="space-y-5">
      {/* Search & Filter Bar */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
            <input
              type="text"
              placeholder="Search by package identifier, name, maintainer, or description..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Category dropdown */}
            <select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-sky-500"
            >
              {CATEGORIES.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>

            {/* Repo filter */}
            <select
              value={selectedRepoId}
              onChange={(e) => setSelectedRepoId(e.target.value)}
              className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-sky-500"
            >
              <option value="all">All Repositories</option>
              {repos.map(r => (
                <option key={r.id} value={String(r.id)}>{r.name}</option>
              ))}
            </select>

            {/* Architecture filter */}
            <select
              value={selectedArch}
              onChange={(e) => setSelectedArch(e.target.value)}
              className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-sky-500"
            >
              <option value="all">All Architectures</option>
              <option value="iphoneos-arm64">iphoneos-arm64</option>
              <option value="iphoneos-arm64e">iphoneos-arm64e</option>
              <option value="iphoneos-arm">iphoneos-arm (32-bit)</option>
            </select>
          </div>
        </div>

        {/* Active filter count & quick resets */}
        <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
          <div>
            Showing <span className="font-mono tabular-nums text-white font-medium">{packages.length}</span> matching package{packages.length === 1 ? '' : 's'}
          </div>

          {(search || selectedSection !== 'All Categories' || selectedRepoId !== 'all' || selectedArch !== 'all' || selectedLegacy !== 'all') && (
            <button
              onClick={() => {
                setSearch('');
                setSelectedSection('All Categories');
                setSelectedRepoId('all');
                setSelectedArch('all');
                setSelectedLegacy('all');
              }}
              className="text-sky-400 hover:text-sky-300 text-xs font-medium cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Package List Grid / Table */}
      {loading ? (
        <div className="p-12 text-center text-slate-400 text-xs">
          Loading package database index...
        </div>
      ) : packages.length === 0 ? (
        <div className="bg-slate-900/60 border border-dashed border-slate-800 rounded-xl p-12 text-center">
          <Package className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <h3 className="text-sm font-semibold text-white">No packages found</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Try adjusting your search criteria or sync additional Debian APT repositories.
          </p>
        </div>
      ) : (
        <div className="border border-slate-800 rounded-xl bg-slate-900/80 overflow-hidden divide-y divide-slate-800/80">
          {packages.map(pkg => (
            <div
              key={pkg.package_id}
              onClick={() => onSelectPackage(pkg)}
              className="p-4 sm:px-6 hover:bg-slate-800/40 transition-colors cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 group"
            >
              <div className="flex items-start gap-3.5">
                {pkg.icon_url ? (
                  <img
                    src={pkg.icon_url}
                    alt={pkg.name}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-lg object-contain bg-slate-950 border border-slate-800 p-1 shrink-0 mt-0.5"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-slate-300 font-bold text-sm shrink-0 mt-0.5">
                    {pkg.name.charAt(0).toUpperCase()}
                  </div>
                )}

                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-white group-hover:text-sky-300 transition-colors">
                      {pkg.name}
                    </span>
                    <span className="font-mono text-xs text-sky-400">v{pkg.latest_version}</span>
                  </div>

                  <div className="font-mono text-[11px] text-slate-400">{pkg.package_id}</div>

                  <div className="text-xs text-slate-300 line-clamp-1 max-w-xl">
                    {pkg.description}
                  </div>

                  {/* Clean unboxed metadata with · separators */}
                  <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400 pt-0.5">
                    <span className="text-slate-300">{pkg.section}</span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="font-mono text-slate-400">{pkg.architecture}</span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-slate-400">{pkg.repo_name || `Repo #${pkg.repo_id}`}</span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-amber-300 font-medium">iOS 10–27 (Cydia / Phoenix)</span>
                    {pkg.is_legacy === 1 && (
                      <>
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span className="text-amber-400 font-medium">Legacy 32-bit</span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 self-end sm:self-center shrink-0">
                <button
                  type="button"
                  className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-slate-300 group-hover:text-white bg-slate-800/80 group-hover:bg-slate-700 border border-slate-700/60 rounded-lg transition-colors"
                >
                  <span>Inspect</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
