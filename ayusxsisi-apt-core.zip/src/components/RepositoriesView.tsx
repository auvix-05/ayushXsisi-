import React, { useState } from 'react';
import {
  RefreshCw,
  FolderGit2,
  Package,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  Trash2,
  Layers,
  ArrowRight
} from 'lucide-react';
import type { Repo } from '../lib/types.ts';
import { api } from '../lib/api.ts';

interface RepositoriesViewProps {
  repos: Repo[];
  onRefresh: () => void;
  onOpenAddModal: () => void;
  onSelectRepoForPackages: (repoId: number) => void;
}

export const RepositoriesView: React.FC<RepositoriesViewProps> = ({
  repos,
  onRefresh,
  onOpenAddModal,
  onSelectRepoForPackages,
}) => {
  const [syncingMap, setSyncingMap] = useState<Record<number, boolean>>({});
  const [syncAllLoading, setSyncAllLoading] = useState(false);
  const [globalMessage, setGlobalMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const totalPackages = repos.reduce((acc, r) => acc + (r.package_count || 0), 0);

  const handleSyncSingle = async (repoId: number) => {
    setSyncingMap(prev => ({ ...prev, [repoId]: true }));
    setGlobalMessage(null);
    try {
      const res = await api.syncRepo(repoId);
      setGlobalMessage({
        type: 'success',
        text: `Successfully synced repository. Parsed and indexed ${res.count || 0} packages.`
      });
      onRefresh();
    } catch (err: any) {
      setGlobalMessage({
        type: 'error',
        text: `Failed to sync repository: ${err.message}`
      });
      onRefresh();
    } finally {
      setSyncingMap(prev => ({ ...prev, [repoId]: false }));
    }
  };

  const handleSyncAll = async () => {
    if (repos.length === 0) return;
    setSyncAllLoading(true);
    setGlobalMessage(null);
    let successCount = 0;
    let failCount = 0;

    for (const repo of repos) {
      setSyncingMap(prev => ({ ...prev, [repo.id]: true }));
      try {
        await api.syncRepo(repo.id);
        successCount++;
      } catch {
        failCount++;
      } finally {
        setSyncingMap(prev => ({ ...prev, [repo.id]: false }));
      }
    }

    setSyncAllLoading(false);
    onRefresh();
    setGlobalMessage({
      type: failCount === 0 ? 'success' : 'error',
      text: `Sync All complete: ${successCount} updated successfully${failCount > 0 ? `, ${failCount} encountered errors` : ''}.`
    });
  };

  const handleDelete = async (repoId: number) => {
    if (!window.confirm('Are you sure you want to delete this repository and all its indexed packages?')) {
      return;
    }
    try {
      await api.deleteRepo(repoId);
      onRefresh();
    } catch (err: any) {
      alert(`Error deleting repo: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Metric summary strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs font-medium text-slate-400">Total APT Repositories</div>
          <div className="mt-2 text-2xl font-bold text-white font-mono tabular-nums">
            {repos.length}
          </div>
          <div className="mt-1 text-xs text-slate-500">Configured APT sources</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs font-medium text-slate-400">Indexed Packages</div>
          <div className="mt-2 text-2xl font-bold text-sky-400 font-mono tabular-nums">
            {totalPackages}
          </div>
          <div className="mt-1 text-xs text-slate-500">Across all active repos</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs font-medium text-slate-400">Security & SSRF Firewall</div>
          <div className="mt-2 flex items-center gap-1.5 text-lg font-bold text-emerald-400">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <span>Enforced</span>
          </div>
          <div className="mt-1 text-xs text-slate-500">RFC 1918 / 3927 guarded</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
          <div className="text-xs font-medium text-slate-400">APT Core Engine</div>
          <div className="mt-2 text-sm font-semibold text-white font-mono truncate">
            ayusXsisi-Cydia-Core/1.0
          </div>
          <div className="mt-1 text-xs text-slate-500">pako gzip + RFC822 parser</div>
        </div>
      </div>

      {/* Global alert banner if present */}
      {globalMessage && (
        <div
          className={`p-4 rounded-xl text-xs flex items-center justify-between border ${
            globalMessage.type === 'success'
              ? 'bg-emerald-950/40 text-emerald-200 border-emerald-800/60'
              : 'bg-red-950/40 text-red-200 border-red-800/60'
          }`}
        >
          <span>{globalMessage.text}</span>
          <button
            onClick={() => setGlobalMessage(null)}
            className="text-xs underline ml-4 hover:opacity-80"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Action header bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-2">
        <div>
          <h2 className="text-lg font-semibold text-white tracking-tight">Active APT Sources</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Repositories offering Debian packages, Cydia tweaks, rootless utilities, and system binaries.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleSyncAll}
            disabled={syncAllLoading || repos.length === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 rounded-lg border border-slate-700/80 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${syncAllLoading ? 'animate-spin text-sky-400' : ''}`} />
            <span>{syncAllLoading ? 'Syncing All...' : 'Sync All Repositories'}</span>
          </button>

          <button
            onClick={onOpenAddModal}
            className="px-3 py-1.5 text-xs font-medium text-white bg-sky-500 hover:bg-sky-400 rounded-lg shadow-sm transition-colors cursor-pointer"
          >
            + Add Custom Repo
          </button>
        </div>
      </div>

      {/* Repository list cards */}
      {repos.length === 0 ? (
        <div className="bg-slate-900/60 border border-dashed border-slate-800 rounded-xl p-12 text-center">
          <FolderGit2 className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <h3 className="text-sm font-semibold text-white">No repositories configured</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Add your first Debian APT repository to index tweaks, libraries, and system applications.
          </p>
          <button
            onClick={onOpenAddModal}
            className="mt-4 px-4 py-2 text-xs font-medium text-white bg-sky-500 hover:bg-sky-400 rounded-lg"
          >
            Add Repository Now
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {repos.map(repo => {
            const isSyncing = syncingMap[repo.id] || repo.sync_status === 'syncing';
            return (
              <div
                key={repo.id}
                className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 hover:border-slate-700/80 transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      {repo.icon_url ? (
                        <img
                          src={repo.icon_url}
                          alt={repo.name}
                          referrerPolicy="no-referrer"
                          className="w-10 h-10 rounded-lg object-contain bg-slate-950 border border-slate-800 p-1"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-slate-300 font-bold text-sm">
                          {repo.name.charAt(0).toUpperCase()}
                        </div>
                      )}
                      <div>
                        <h3 className="text-sm font-semibold text-white group-hover:text-sky-300 transition-colors">
                          {repo.name}
                        </h3>
                        <a
                          href={repo.url}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-sky-400 transition-colors font-mono truncate max-w-xs"
                        >
                          <span className="truncate">{repo.url}</span>
                          <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                        </a>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDelete(repo.id)}
                      title="Remove Repository"
                      className="text-slate-500 hover:text-red-400 transition-colors p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Metadata and Status */}
                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                    <div className="flex items-center gap-2">
                      <Package className="w-3.5 h-3.5 text-slate-500" />
                      <span className="font-mono tabular-nums text-slate-200">
                        {repo.package_count || 0}
                      </span>
                      <span>packages indexed</span>
                    </div>

                    {/* Sync Status Badge */}
                    <div className="flex items-center gap-1.5">
                      {isSyncing ? (
                        <span className="flex items-center gap-1 text-sky-400">
                          <RefreshCw className="w-3 h-3 animate-spin" />
                          <span>Syncing...</span>
                        </span>
                      ) : repo.sync_status === 'success' ? (
                        <span className="flex items-center gap-1 text-emerald-400">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Synchronized</span>
                        </span>
                      ) : repo.sync_status === 'error' ? (
                        <span className="flex items-center gap-1 text-red-400">
                          <AlertTriangle className="w-3 h-3" />
                          <span>Sync Error</span>
                        </span>
                      ) : (
                        <span className="text-slate-500">Idle</span>
                      )}
                    </div>
                  </div>

                  {/* Sync error explanation if any */}
                  {repo.error_message && (
                    <div className="mt-2.5 p-2 bg-red-950/40 border border-red-900/60 rounded text-[11px] text-red-300 font-mono break-all">
                      {repo.error_message}
                    </div>
                  )}

                  {/* Last synced date */}
                  <div className="mt-1 text-[11px] text-slate-500">
                    Last sync:{' '}
                    {repo.last_sync
                      ? new Date(repo.last_sync).toLocaleString()
                      : 'Never synchronized'}
                  </div>
                </div>

                {/* Card footer actions */}
                <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                  <button
                    onClick={() => onSelectRepoForPackages(repo.id)}
                    className="flex items-center gap-1 text-xs text-sky-400 hover:text-sky-300 transition-colors font-medium"
                  >
                    <span>Browse Packages</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>

                  <button
                    onClick={() => handleSyncSingle(repo.id)}
                    disabled={isSyncing}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 rounded-lg transition-colors cursor-pointer"
                  >
                    <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin text-sky-400' : ''}`} />
                    <span>{isSyncing ? 'Syncing...' : 'Sync Index'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
