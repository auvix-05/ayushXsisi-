import React from 'react';
import { Database, Plus } from 'lucide-react';

interface TopNavProps {
  currentTab: 'repos' | 'packages' | 'parser' | 'ssrf' | 'logs';
  onSelectTab: (tab: 'repos' | 'packages' | 'parser' | 'ssrf' | 'logs') => void;
  onOpenAddModal: () => void;
  repoCount: number;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentTab,
  onSelectTab,
  onOpenAddModal,
  repoCount
}) => {
  return (
    <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur sticky top-0 z-40">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-6 py-3.5">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
          <div className="w-8 h-8 rounded-lg overflow-hidden border border-slate-700 bg-white flex items-center justify-center shadow-sm shrink-0">
            <img
              src="/assets/aistudio/image_1779022121296_31f14b66.jpg"
              alt="ayusXsisi APT Core Logo"
              className="w-full h-full object-cover"
            />
          </div>
          <button
            onClick={() => onSelectTab('repos')}
            className="text-base font-semibold tracking-tight text-white hover:text-sky-300 transition-colors text-left"
          >
            ayusXsisi APT Core
          </button>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-400">
          <button
            onClick={() => onSelectTab('repos')}
            className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 ${
              currentTab === 'repos'
                ? 'text-white border-b-2 border-sky-400 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            Repositories ({repoCount})
          </button>
          <button
            onClick={() => onSelectTab('packages')}
            className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 ${
              currentTab === 'packages'
                ? 'text-white border-b-2 border-sky-400 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            Package Explorer
          </button>
          <button
            onClick={() => onSelectTab('parser')}
            className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 ${
              currentTab === 'parser'
                ? 'text-white border-b-2 border-sky-400 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            RFC822 Control Parser
          </button>
          <button
            onClick={() => onSelectTab('ssrf')}
            className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 ${
              currentTab === 'ssrf'
                ? 'text-white border-b-2 border-sky-400 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            SSRF Security Auditor
          </button>
          <button
            onClick={() => onSelectTab('logs')}
            className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 ${
              currentTab === 'logs'
                ? 'text-white border-b-2 border-sky-400 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            Import Logs
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenAddModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-sky-500 hover:bg-sky-400 rounded-md shadow-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Repository</span>
          </button>
        </div>
      </div>

      {/* Mobile nav drawer */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-800/80 px-2 py-2 text-xs text-slate-400 overflow-x-auto">
        <button
          onClick={() => onSelectTab('repos')}
          className={`px-2 py-1 ${currentTab === 'repos' ? 'text-sky-400 font-medium' : ''}`}
        >
          Repos
        </button>
        <button
          onClick={() => onSelectTab('packages')}
          className={`px-2 py-1 ${currentTab === 'packages' ? 'text-sky-400 font-medium' : ''}`}
        >
          Packages
        </button>
        <button
          onClick={() => onSelectTab('parser')}
          className={`px-2 py-1 ${currentTab === 'parser' ? 'text-sky-400 font-medium' : ''}`}
        >
          RFC822 Parser
        </button>
        <button
          onClick={() => onSelectTab('ssrf')}
          className={`px-2 py-1 ${currentTab === 'ssrf' ? 'text-sky-400 font-medium' : ''}`}
        >
          SSRF Auditor
        </button>
        <button
          onClick={() => onSelectTab('logs')}
          className={`px-2 py-1 ${currentTab === 'logs' ? 'text-sky-400 font-medium' : ''}`}
        >
          Logs
        </button>
      </div>
    </header>
  );
};
