import React, { useState, useEffect } from 'react';
import {
  FileCode,
  Play,
  CheckCircle2,
  AlertTriangle,
  Upload,
  Copy,
  Check,
  PlusCircle,
  Database
} from 'lucide-react';
import { parseDebianControl, mapSectionToCategory, lintDebianControl } from '../lib/debian-parser.ts';
import { db } from '../lib/db.ts';

const SAMPLE_TEMPLATES = {
  tweak: `Package: com.opa334.choicy
Name: Choicy
Version: 1.4.11
Architecture: iphoneos-arm64
Maintainer: opa334 <opa334@github.com>
Author: opa334
Section: Tweaks
Depends: mobilesubstrate (>= 0.9.5000), preferenceloader
Description: Advanced, granular tweak configurator
 Choicy allows you to selectively configure tweak injection on a per-process basis.
 Supports iOS 11 through 16.x on both rootful and rootless environments.
 You can blacklist or whitelist specific dylibs from loading.
Icon: https://opa334.github.io/icons/com.opa334.choicy.png
Size: 428912
MD5sum: f9d3b7643b17c2f82110c732b13f19e4`,

  daemon: `Package: openssh
Name: OpenSSH Server & Client
Version: 9.6p1-1
Architecture: iphoneos-arm64
Maintainer: Procursus Team <maintainers@procurs.us>
Author: OpenSSH Project
Section: Networking
Depends: libssl3, libcrypt2, libedit0
Description: Secure shell client and server daemon
 OpenSSH is the premier connectivity tool for remote login with SSH protocol.
 It encrypts all traffic to eliminate eavesdropping and connection hijacking.
Size: 1420800
MD5sum: 5eb63bbbe01eeed093cb22bb8f5acdc3`,

  multi: `Package: com.spark.snowboard
Name: SnowBoard
Version: 1.5.28-Beta1
Architecture: iphoneos-arm64
Maintainer: SparkDev <spark@sparkdev.me>
Section: Themes
Depends: mobilesubstrate, preferenceloader
Conflicts: winterboard, anemone
Description: Lightweight theming engine for iOS
 Modular, battery-efficient theme engine.
Size: 849312

Package: com.spark.snowboard.statusbar
Name: SnowBoard StatusBar Extension
Version: 1.0.12-Beta1
Architecture: iphoneos-arm64
Maintainer: SparkDev <spark@sparkdev.me>
Section: Status Bar
Depends: com.spark.snowboard
Description: Status bar UI theming extension for SnowBoard
 Allows custom WiFi, cellular, and battery icons.
Size: 124800`
};

interface ControlPlaygroundProps {
  onPackageImported?: () => void;
}

export const ControlPlaygroundView: React.FC<ControlPlaygroundProps> = ({ onPackageImported }) => {
  const [controlText, setControlText] = useState(SAMPLE_TEMPLATES.tweak);
  const [parsedPackages, setParsedPackages] = useState<any[]>([]);
  const [lintResults, setLintResults] = useState<any>(null);
  const [copied, setCopied] = useState(false);
  const [importedMessage, setImportedMessage] = useState<string | null>(null);

  const runParse = () => {
    const pkgs = parseDebianControl(controlText);
    const lint = lintDebianControl(controlText);
    const enriched = pkgs.map(p => ({
      ...p,
      mappedCategory: mapSectionToCategory(p['section'] || '')
    }));
    setParsedPackages(enriched);
    setLintResults(lint);
  };

  useEffect(() => {
    runParse();
  }, [controlText]);

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(parsedPackages, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleImportToDb = () => {
    if (parsedPackages.length === 0) return;
    try {
      const insertPkgStmt = db.prepare(`
        INSERT INTO packages (
          package_id, name, section, latest_version, description, maintainer,
          author, architecture, icon_url, download_url, min_ios, max_ios,
          compatibility_status, is_legacy, repo_id, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(package_id) DO UPDATE SET
          latest_version = excluded.latest_version,
          name = excluded.name,
          section = excluded.section,
          description = excluded.description,
          download_url = excluded.download_url,
          architecture = excluded.architecture,
          updated_at = CURRENT_TIMESTAMP
      `);

      const insertVerStmt = db.prepare(`
        INSERT INTO package_versions (
          package_id, version, download_url, size_bytes, md5sum, sha256,
          dependencies, conflicts, architecture, repo_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(package_id, version) DO UPDATE SET
          download_url = excluded.download_url,
          dependencies = excluded.dependencies,
          conflicts = excluded.conflicts
      `);

      for (const p of parsedPackages) {
        const pkgIdentifier = p['package'];
        const version = p['version'];
        const name = p['name'] || pkgIdentifier;
        const section = p['mappedCategory'];
        const description = p['description'] || '';
        const maintainer = p['maintainer'] || p['author'] || 'Unknown Maintainer';
        const architecture = p['architecture'] || 'iphoneos-arm64';
        const icon = p['icon'] || null;
        const depends = p['depends'] || '';
        const isLegacy = depends.includes('firmware (<=') || section === 'Legacy Packages' || architecture === 'iphoneos-arm' ? 1 : 0;

        insertPkgStmt.run(
          pkgIdentifier, name, section, version, description,
          maintainer, maintainer, architecture, icon, null,
          null, null, 'Verified', isLegacy, 1
        );

        insertVerStmt.run(
          pkgIdentifier, version, null,
          p['size'] ? parseInt(p['size'], 10) : 0,
          p['md5sum'] || null, p['sha256'] || null,
          depends, p['conflicts'] || null, architecture, 1
        );
      }

      setImportedMessage(`Imported ${parsedPackages.length} package(s) into database successfully!`);
      if (onPackageImported) onPackageImported();
      setTimeout(() => setImportedMessage(null), 4000);
    } catch (err: any) {
      alert(`Import error: ${err.message}`);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-white tracking-tight">Debian RFC822 Control Playground</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Test and audit Debian control format multiline continuation folding, category classification, and field linter.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setControlText(SAMPLE_TEMPLATES.tweak)}
            className="px-2.5 py-1.5 bg-slate-900 border border-slate-800 hover:bg-slate-800 text-xs text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            Tweak Preset
          </button>
          <button
            onClick={() => setControlText(SAMPLE_TEMPLATES.daemon)}
            className="px-2.5 py-1.5 bg-slate-900 border border-slate-800 hover:bg-slate-800 text-xs text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            Daemon Preset
          </button>
          <button
            onClick={() => setControlText(SAMPLE_TEMPLATES.multi)}
            className="px-2.5 py-1.5 bg-slate-900 border border-slate-800 hover:bg-slate-800 text-xs text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            Multi-Package (Packages.gz)
          </button>
        </div>
      </div>

      {importedMessage && (
        <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-xl text-xs text-emerald-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{importedMessage}</span>
          </div>
          <span className="text-[11px] text-slate-400">Available in Package Explorer</span>
        </div>
      )}

      {/* Editor & Results Split */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Left: Raw text editor */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden flex flex-col h-[600px]">
          <div className="px-4 py-3 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-300 font-medium">
              <FileCode className="w-4 h-4 text-sky-400" />
              <span>Raw RFC822 Input</span>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">
              Debian Policy Manual 5.1
            </span>
          </div>

          <textarea
            value={controlText}
            onChange={(e) => setControlText(e.target.value)}
            className="flex-1 p-4 bg-slate-950/60 text-slate-200 font-mono text-xs leading-relaxed resize-none focus:outline-none"
            placeholder="Paste Debian RFC822 control file text or Packages index stream here..."
            spellCheck={false}
          />

          <div className="px-4 py-3 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-400">
              Lines starting with space/tab represent multiline continuation.
            </span>
            <button
              onClick={runParse}
              className="flex items-center gap-1.5 px-3 py-1 bg-sky-500 hover:bg-sky-400 text-white font-medium rounded-md shadow-sm transition-colors cursor-pointer"
            >
              <Play className="w-3 h-3" />
              <span>Reparse</span>
            </button>
          </div>
        </div>

        {/* Right: Parsed AST & Linter */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden flex flex-col h-[600px]">
          <div className="px-4 py-3 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-300 font-medium">
              <Database className="w-4 h-4 text-emerald-400" />
              <span>Parsed Structures ({parsedPackages.length})</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyJson}
                className="flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300 cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied' : 'Copy JSON'}</span>
              </button>
              <button
                onClick={handleImportToDb}
                disabled={parsedPackages.length === 0}
                className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 rounded-md transition-colors cursor-pointer"
              >
                <PlusCircle className="w-3 h-3" />
                <span>Save to DB</span>
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* Linter warnings & errors */}
            {lintResults && (
              <div className="space-y-2">
                {lintResults.errors.length > 0 && (
                  <div className="p-3 bg-red-950/40 border border-red-900/60 rounded-lg text-xs space-y-1">
                    <div className="font-semibold text-red-300 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-red-400" />
                      <span>Debian RFC822 Syntax Errors</span>
                    </div>
                    {lintResults.errors.map((e: string, idx: number) => (
                      <div key={idx} className="text-red-200 text-[11px] pl-5">• {e}</div>
                    ))}
                  </div>
                )}

                {lintResults.warnings.length > 0 && (
                  <div className="p-3 bg-amber-950/30 border border-amber-900/50 rounded-lg text-xs space-y-1">
                    <div className="font-semibold text-amber-300 flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                      <span>Policy Warnings</span>
                    </div>
                    {lintResults.warnings.map((w: string, idx: number) => (
                      <div key={idx} className="text-amber-200 text-[11px] pl-5">• {w}</div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Parsed packages preview cards */}
            {parsedPackages.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs">
                No valid Debian packages parsed. Ensure input contains `Package:` and `Version:` keys.
              </div>
            ) : (
              parsedPackages.map((pkg, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 space-y-2.5 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div className="font-semibold text-white flex items-center gap-2">
                      <span>{pkg['name'] || pkg['package']}</span>
                      <span className="text-[11px] text-sky-400 font-mono">v{pkg['version']}</span>
                    </div>
                    <span className="text-[11px] font-mono text-slate-400">
                      {pkg['architecture'] || 'iphoneos-arm'}
                    </span>
                  </div>

                  <div className="text-[11px] font-mono text-slate-400">{pkg['package']}</div>

                  <div className="p-2 bg-slate-900 rounded text-slate-300 whitespace-pre-wrap font-sans text-xs">
                    {pkg['description']}
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-slate-850">
                    <div>
                      <span className="text-slate-500">Category: </span>
                      <span className="text-slate-300 font-medium">{pkg['mappedCategory']}</span>
                    </div>
                    <div>
                      <span className="text-slate-500">Raw Section: </span>
                      <span className="text-slate-300">{pkg['section'] || 'None'}</span>
                    </div>
                    {pkg['depends'] && (
                      <div className="col-span-2 font-mono text-[11px]">
                        <span className="text-slate-500">Depends: </span>
                        <span className="text-slate-300">{pkg['depends']}</span>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
