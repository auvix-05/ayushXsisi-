import React, { useState } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';

interface WebsiteNavProps {
  onOpenSubmit: () => void;
}

export const WebsiteNav: React.FC<WebsiteNavProps> = ({ onOpenSubmit }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-[#090d16]/90 backdrop-blur-md border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-6 py-3.5">
        {/* Zone 1: Brand Wordmark with Logo */}
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex items-center gap-2.5 whitespace-nowrap shrink-0 group"
        >
          <div className="w-8 h-8 rounded-lg overflow-hidden border border-slate-700 bg-white flex items-center justify-center shadow-sm shrink-0 transition-transform group-hover:scale-105">
            <img
              src="/assets/aistudio/image_1779022121296_31f14b66.jpg"
              alt="ayusXsisi APT Core Logo"
              className="w-full h-full object-cover"
            />
          </div>
          <span className="text-base font-semibold tracking-tight text-white group-hover:text-sky-300 transition-colors">
            ayusXsisi APT Core
          </span>
        </a>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-400">
          <button
            onClick={() => scrollTo('capabilities')}
            className="whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer"
          >
            Capabilities
          </button>
          <button
            onClick={() => scrollTo('interactive-showcase')}
            className="whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer"
          >
            Live Sandbox
          </button>
          <button
            onClick={() => scrollTo('security-matrix')}
            className="whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer"
          >
            SSRF Defense
          </button>
          <button
            onClick={() => scrollTo('architecture-specs')}
            className="whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer"
          >
            Engine Specs
          </button>
          <button
            onClick={() => scrollTo('submit-repo')}
            className="whitespace-nowrap shrink-0 hover:text-white transition-colors cursor-pointer"
          >
            Submit Repo
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="hidden md:flex items-center gap-3 shrink-0">
          <button
            onClick={() => scrollTo('interactive-showcase')}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-sky-500 hover:bg-sky-400 rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span>Launch Live Sandbox</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Mobile menu toggle */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden text-slate-400 hover:text-white p-1"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile menu dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-950 border-b border-slate-800 px-6 py-4 space-y-3 text-sm">
          <button
            onClick={() => scrollTo('capabilities')}
            className="block text-slate-300 hover:text-white w-full text-left py-1"
          >
            Capabilities
          </button>
          <button
            onClick={() => scrollTo('interactive-showcase')}
            className="block text-slate-300 hover:text-white w-full text-left py-1"
          >
            Live Sandbox
          </button>
          <button
            onClick={() => scrollTo('security-matrix')}
            className="block text-slate-300 hover:text-white w-full text-left py-1"
          >
            SSRF Defense
          </button>
          <button
            onClick={() => scrollTo('architecture-specs')}
            className="block text-slate-300 hover:text-white w-full text-left py-1"
          >
            Engine Specs
          </button>
          <button
            onClick={() => scrollTo('submit-repo')}
            className="block text-slate-300 hover:text-white w-full text-left py-1"
          >
            Submit Repo
          </button>
          <div className="pt-2">
            <button
              onClick={() => scrollTo('interactive-showcase')}
              className="w-full py-2 text-center text-xs font-semibold text-white bg-sky-500 rounded-lg"
            >
              Launch Live Sandbox
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
