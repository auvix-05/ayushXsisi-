import React, { useState } from 'react';
import { Terminal, Copy, Check, ShieldCheck, FileCheck, Code2 } from 'lucide-react';

const CODE_SNIPPET = `const pako = require('pako');
const { validateSafeUrl } = require('./ssrf');
const { db } = require('./db');

/**
 * Parses Debian RFC822 control format text into array of structured key-value maps.
 * Handles folded/multiline fields according to Debian Policy Manual standards.
 */
function parseDebianControl(rawText) {
  const blocks = rawText.split(/\\r?\\n\\r?\\n/);
  const packages = [];

  for (const block of blocks) {
    if (!block.trim()) continue;
    const lines = block.split(/\\r?\\n/);
    const pkgData = {};
    let currentKey = null;

    for (const line of lines) {
      if (line.startsWith(' ') || line.startsWith('\\t')) {
        if (currentKey) pkgData[currentKey] += '\\n' + line.trim();
      } else {
        const colonIndex = line.indexOf(':');
        if (colonIndex !== -1) {
          currentKey = line.substring(0, colonIndex).trim().toLowerCase();
          pkgData[currentKey] = line.substring(colonIndex + 1).trim();
        }
      }
    }
    if (pkgData['package'] && pkgData['version']) packages.push(pkgData);
  }
  return packages;
}

/**
 * Downloads with custom timeout and strict byte length cap to protect server resources.
 */
async function fetchSafeStream(url, maxBytes = 25 * 1024 * 1024) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000); // 20s cap
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { 'User-Agent': 'ayusXsisi-Cydia-Core/1.0 (Debian-APT; Security-Audited)' }
    });
    if (!res.ok) throw new Error(\`HTTP \${res.status}: \${res.statusText}\`);
    const arrayBuffer = await res.arrayBuffer();
    if (arrayBuffer.byteLength > maxBytes) throw new Error('Response exceeded 25MB cap.');
    return Buffer.from(arrayBuffer);
  } finally {
    clearTimeout(timeout);
  }
}`;

export const ArchitectureSpecsSection: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(CODE_SNIPPET);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="architecture-specs" className="py-20 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Spec Details */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <div className="text-xs font-semibold text-sky-400 font-mono tracking-wide uppercase">
                Technical Blueprint
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-2">
                Audited Core Implementation
              </h2>
              <p className="text-sm text-slate-400 mt-2 leading-relaxed">
                Clean, battle-tested Node.js primitives ensuring deterministic parsing and impervious network isolation for enterprise APT infrastructure.
              </p>
            </div>

            <div className="space-y-4 text-xs text-slate-300">
              <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl space-y-1.5">
                <div className="font-semibold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>SSRF Pre-Flight Validation Matrix</span>
                </div>
                <p className="text-slate-400 leading-relaxed text-[11px]">
                  Every URL must pass strict protocol whitelist verification and resolved IP checks against RFC 1918, RFC 3927, and RFC 1122 prior to socket allocation.
                </p>
              </div>

              <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl space-y-1.5">
                <div className="font-semibold text-white flex items-center gap-2">
                  <FileCheck className="w-4 h-4 text-sky-400" />
                  <span>Dual Index Resolution Fallback</span>
                </div>
                <p className="text-slate-400 leading-relaxed text-[11px]">
                  Automatically requests <code className="text-sky-300">Packages.gz</code> using streaming gzip decompression with <code className="text-sky-300">pako</code>, seamlessly degrading to uncompressed <code className="text-sky-300">Packages</code> if archive decompression is unavailable.
                </p>
              </div>

              <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl space-y-1.5">
                <div className="font-semibold text-white flex items-center gap-2">
                  <Code2 className="w-4 h-4 text-indigo-400" />
                  <span>Debian Policy Multiline Continuation</span>
                </div>
                <p className="text-slate-400 leading-relaxed text-[11px]">
                  Properly maintains parser state across folded lines prefixed with whitespace or tabs, guaranteeing package descriptions and dependency lists are never clipped.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Code Snippet Card */}
          <div className="lg:col-span-7">
            <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
              <div className="px-5 py-3 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 font-mono text-slate-300">
                  <Terminal className="w-4 h-4 text-sky-400" />
                  <span>ayusXsisi-cydia-core.js</span>
                </div>
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1.5 text-xs text-sky-400 hover:text-sky-300 transition-colors cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy Code'}</span>
                </button>
              </div>

              <pre className="p-5 font-mono text-xs text-slate-300 leading-relaxed overflow-x-auto max-h-[500px]">
                <code>{CODE_SNIPPET}</code>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
