import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Search,
  Lock,
  Globe,
  Radio,
  FileWarning,
  Server,
  Terminal,
  Info
} from 'lucide-react';
import { api } from '../lib/api.ts';
import type { SSRFResult } from '../lib/types.ts';

const PRESET_TARGETS = [
  {
    category: 'Attack Simulations (Expected Block)',
    items: [
      { label: 'AWS/GCP Metadata Endpoint', url: 'http://169.254.169.254/latest/meta-data' },
      { label: 'Google Internal Metadata Host', url: 'http://metadata.google.internal/computeMetadata/v1/' },
      { label: 'Loopback Host (127.0.0.1)', url: 'http://127.0.0.1:8080/internal-admin' },
      { label: 'Class A Private Network (10.0.0.0/8)', url: 'http://10.0.0.1/Packages.gz' },
      { label: 'Class B Private Network (172.16.0.0/12)', url: 'http://172.16.1.10/Packages' },
      { label: 'Class C Private Network (192.168.0.0/16)', url: 'http://192.168.1.1/router-login' },
      { label: 'Disallowed Scheme (file://)', url: 'file:///etc/passwd' },
    ]
  },
  {
    category: 'Authorized External APT Repositories (Expected Allow)',
    items: [
      { label: 'Chariz Official APT', url: 'https://repo.chariz.com/Packages.gz' },
      { label: 'Havoc Community APT', url: 'https://havoc.app/Packages' },
      { label: 'Procursus APT Bootstrap', url: 'https://apt.procurs.us/Packages.gz' },
      { label: 'opa334 GitHub Pages Repo', url: 'https://opa334.github.io/Packages' },
    ]
  }
];

export const SsrfAuditorView: React.FC = () => {
  const [targetUrl, setTargetUrl] = useState('http://169.254.169.254/latest/meta-data');
  const [result, setResult] = useState<SSRFResult | null>(null);
  const [loading, setLoading] = useState(false);

  const runAudit = async (testUrl?: string) => {
    const urlToTest = testUrl || targetUrl;
    if (!urlToTest.trim()) return;

    setLoading(true);
    try {
      const res = await api.testSsrf(urlToTest.trim());
      setResult(res);
    } catch (err: any) {
      setResult({
        safe: false,
        reason: `Verification exception: ${err.message}`
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePresetClick = (presetUrl: string) => {
    setTargetUrl(presetUrl);
    runAudit(presetUrl);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-lg font-semibold text-white tracking-tight">SSRF Prevention & Security Auditor</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Audits outgoing repository URLs against private IP subnets, loopback interfaces, cloud metadata endpoints, and DNS rebinding attacks.
        </p>
      </div>

      {/* Audit Search Bar */}
      <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-4">
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1.5">
            Test Target Repository Endpoint URL
          </label>
          <div className="flex gap-2.5">
            <input
              type="text"
              value={targetUrl}
              onChange={(e) => setTargetUrl(e.target.value)}
              placeholder="e.g. http://169.254.169.254/ or https://repo.chariz.com/"
              className="flex-1 px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white placeholder-slate-500 font-mono focus:outline-none focus:border-sky-500"
            />
            <button
              onClick={() => runAudit()}
              disabled={loading}
              className="px-5 py-2.5 bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-white font-medium text-xs rounded-lg shadow-sm transition-colors cursor-pointer shrink-0"
            >
              {loading ? 'Evaluating...' : 'Run SSRF Audit'}
            </button>
          </div>
        </div>

        {/* Audit result card */}
        {result && (
          <div
            className={`p-5 rounded-xl border ${
              result.safe
                ? 'bg-emerald-950/30 border-emerald-800/60 text-emerald-200'
                : 'bg-red-950/30 border-red-800/60 text-red-200'
            }`}
          >
            <div className="flex items-start gap-3">
              {result.safe ? (
                <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <ShieldAlert className="w-6 h-6 text-red-400 shrink-0 mt-0.5" />
              )}
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold">
                    {result.safe ? 'TARGET ALLOWED: SSRF Check Passed' : 'REQUEST BLOCKED: SSRF Violation Detected'}
                  </h3>
                  <span className="font-mono text-xs px-2 py-0.5 rounded bg-black/40">
                    {result.safe ? 'ALLOW' : 'DENY'}
                  </span>
                </div>

                <div className="text-xs opacity-90 leading-relaxed font-sans">
                  {result.reason || `Target host is verified external and resolves to safe IP: ${result.ip}`}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-white/10 text-xs font-mono">
                  <div>
                    <span className="opacity-60">Hostname: </span>
                    <span>{result.hostname || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="opacity-60">Resolved IP: </span>
                    <span>{result.ip || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="opacity-60">Protocol: </span>
                    <span>{result.protocol || 'http(s)'}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Attack Scenarios & Presets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {PRESET_TARGETS.map((group) => (
          <div key={group.category} className="bg-slate-900/90 border border-slate-800 p-5 rounded-xl space-y-3">
            <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              {group.category}
            </h3>
            <div className="space-y-2">
              {group.items.map((item) => (
                <button
                  key={item.url}
                  onClick={() => handlePresetClick(item.url)}
                  className="w-full text-left p-3 bg-slate-950/80 hover:bg-slate-800/80 border border-slate-800 rounded-lg transition-colors flex items-center justify-between group cursor-pointer"
                >
                  <div className="truncate mr-3">
                    <div className="text-xs font-medium text-slate-200 group-hover:text-sky-300 transition-colors">
                      {item.label}
                    </div>
                    <div className="text-[11px] font-mono text-slate-500 truncate mt-0.5">
                      {item.url}
                    </div>
                  </div>
                  <Search className="w-3.5 h-3.5 text-slate-600 group-hover:text-sky-400 shrink-0" />
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Policy Standards Reference */}
      <div className="bg-slate-900/50 border border-slate-800 p-5 rounded-xl space-y-3 text-xs text-slate-400">
        <h3 className="font-semibold text-slate-200 flex items-center gap-2">
          <Info className="w-4 h-4 text-sky-400" />
          <span>ayusXsisi Security Standards & Specifications</span>
        </h3>
        <p className="leading-relaxed">
          The APT Core engine enforces multi-layer network protection before initiating any HTTP/HTTPS socket request:
        </p>
        <ul className="space-y-1.5 pl-4 list-disc text-slate-300 text-[11px]">
          <li><strong>RFC 1122:</strong> Complete loopback isolation (<code className="text-sky-300">127.0.0.0/8</code>, <code className="text-sky-300">::1</code>).</li>
          <li><strong>RFC 1918:</strong> Complete private address rejection (<code className="text-sky-300">10.0.0.0/8</code>, <code className="text-sky-300">172.16.0.0/12</code>, <code className="text-sky-300">192.168.0.0/16</code>).</li>
          <li><strong>RFC 3927:</strong> Link-Local & Cloud Metadata defense (<code className="text-sky-300">169.254.0.0/16</code>, <code className="text-sky-300">metadata.google.internal</code>).</li>
          <li><strong>RFC 4291 / 4193:</strong> IPv6 Link-Local and Unique Local Address rejection (<code className="text-sky-300">fe80::/10</code>, <code className="text-sky-300">fc00::/7</code>).</li>
          <li><strong>Resource Capping:</strong> Strict 20-second timeout, 25MB response length cap, and audited User-Agent header <code className="text-sky-300">ayusXsisi-Cydia-Core/1.0</code>.</li>
        </ul>
      </div>
    </div>
  );
};
