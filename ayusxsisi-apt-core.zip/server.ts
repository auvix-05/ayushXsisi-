import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { db } from './src/lib/db.ts';
import { syncRepo } from './src/lib/repo-sync.ts';
import { validateSafeUrl } from './src/lib/ssrf.ts';
import { parseDebianControl, mapSectionToCategory, lintDebianControl } from './src/lib/debian-parser.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  app.use(express.json({ limit: '30mb' }));
  app.use(express.urlencoded({ extended: true, limit: '30mb' }));

  // API Endpoints
  // 1. Repositories
  app.get('/api/repos', (req, res) => {
    try {
      const repos = db.prepare('SELECT * FROM repos').all();
      res.json({ success: true, data: repos });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post('/api/repos', async (req, res) => {
    try {
      const { name, url, icon_url } = req.body;
      if (!url || typeof url !== 'string') {
        return res.status(400).json({ success: false, error: 'Repository URL is required.' });
      }

      // Check SSRF before adding
      const ssrfCheck = await validateSafeUrl(url);
      if (!ssrfCheck.safe) {
        return res.status(400).json({ success: false, error: `SSRF Block: ${ssrfCheck.reason}` });
      }

      let repoName = name;
      if (!repoName) {
        try {
          const u = new URL(url);
          repoName = u.hostname;
        } catch {
          repoName = 'Custom Repo';
        }
      }

      const result = db.prepare('INSERT INTO repos (name, url, icon_url) VALUES (?, ?, ?)').run(repoName, url, icon_url || null);
      const newRepo = db.prepare('SELECT * FROM repos WHERE id = ?').get(result.lastInsertRowid);
      res.json({ success: true, data: newRepo });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.delete('/api/repos/:id', (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      db.prepare('DELETE FROM repos WHERE id = ?').run(id);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post('/api/repos/:id/sync', async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const syncResult = await syncRepo(id);
      res.json(syncResult);
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // 2. Packages
  app.get('/api/packages', (req, res) => {
    try {
      let packages = db.prepare('SELECT * FROM packages').all() as any[];
      const { search, section, repo_id, architecture, legacy } = req.query;

      if (search && typeof search === 'string') {
        const query = search.toLowerCase();
        packages = packages.filter(p =>
          p.package_id.toLowerCase().includes(query) ||
          p.name.toLowerCase().includes(query) ||
          p.maintainer.toLowerCase().includes(query) ||
          p.description.toLowerCase().includes(query)
        );
      }

      if (section && typeof section === 'string' && section !== 'all') {
        packages = packages.filter(p => p.section === section);
      }

      if (repo_id && typeof repo_id === 'string' && repo_id !== 'all') {
        const rid = parseInt(repo_id, 10);
        packages = packages.filter(p => p.repo_id === rid);
      }

      if (architecture && typeof architecture === 'string' && architecture !== 'all') {
        packages = packages.filter(p => p.architecture === architecture);
      }

      if (legacy !== undefined && legacy !== 'all') {
        const isLeg = legacy === '1' ? 1 : 0;
        packages = packages.filter(p => p.is_legacy === isLeg);
      }

      res.json({ success: true, data: packages });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.get('/api/packages/:id', (req, res) => {
    try {
      const pkgId = req.params.id;
      const pkg = db.getPackageWithVersions(pkgId);
      if (!pkg) {
        return res.status(404).json({ success: false, error: 'Package not found' });
      }
      res.json({ success: true, data: pkg });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // 3. RFC822 Control Format Parser & Linter
  app.post('/api/parse-control', (req, res) => {
    try {
      const { text } = req.body;
      if (!text || typeof text !== 'string') {
        return res.status(400).json({ success: false, error: 'Control raw text is required.' });
      }

      const parsed = parseDebianControl(text);
      const lint = lintDebianControl(text);

      const enriched = parsed.map(p => ({
        ...p,
        mappedCategory: mapSectionToCategory(p['section'] || '')
      }));

      res.json({
        success: true,
        count: enriched.length,
        packages: enriched,
        lint
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // 4. SSRF Auditor Endpoint
  app.post('/api/ssrf/audit', async (req, res) => {
    try {
      const { url } = req.body;
      if (!url || typeof url !== 'string') {
        return res.status(400).json({ success: false, error: 'Target URL is required.' });
      }

      const audit = await validateSafeUrl(url);
      res.json({ success: true, data: audit });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // 5. Import logs
  app.get('/api/logs', (req, res) => {
    try {
      const logs = db.prepare('SELECT * FROM import_logs').all();
      res.json({ success: true, data: logs });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Vite Integration
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ayusXsisi APT Core server online on port ${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
